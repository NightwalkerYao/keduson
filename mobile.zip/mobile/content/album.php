<h1 style="font-size: 22pt;" class="light-blue-text"><?=$T['artiste'].' - '.$T['nom'];?> - mp3 - 320 kbps</h1>
<div class="divider orange"></div>

<div class="filmaltiimg">
	<a href="<?=M_ABOUT_ALBUM.'/'.$T['code_name'];?>">
		<img style="padding: 0 0px 0 0; width: 100%;" src="<?=ROOT_SANS.'/covers/'.$T['pochette'];?>" alt="<?=$T['artiste'].' - '.$T['nom'];?>" />
	</a>
</div>
<br>
<div class="filmicerik">
	<div align="center">
		<iframe src="<?=ROOT_SANS.'/play/liste/'.$T['code_name'];?>" style="border-width:0px;" frameborder="0" scrolling="no" height="366" width="100%"></iframe>
	</div>
</div>
<br>
<div id="alt">
	<div class="facebok" align="center">
	<a id="albumaddlike" href="#" data-albumCN="<?=$T['code_name'];?>" data-like="1" style="position: relative;top: -10px; font-size: 11pt; cursor: pointer; font-weight: normal;"><img style="position: relative; top: 8px;" width="30" height="30" src="<?=ROOT_SANS;?>/css/images/icons8-Facebook Like.png" alt="Top"> Top(<span id="nbtlikes"><?=$T['likes'];?></span>)</a>		
	<a id="albumadddislike" href="#" data-albumCN="<?=$T['code_name'];?>" data-like="0" style="position: relative;top: -10px; font-size: 11pt; cursor: pointer; font-weight: normal;"><img style="position: relative; top: 8px;" width="30" height="30" src="<?=ROOT_SANS;?>/css/images/icons8-Thumbs Down.png" alt="Flop"> Flop(<span id="nbtulikes"><?=$T['dislikes'];?></span>)</a>
	<a href="#comments" style="position: relative;top: -10px; font-size: 11pt; cursor: pointer; font-weight: normal;"><img style="position: relative; top: 8px;" width="30" height="30" src="<?=ROOT_SANS;?>/css/images/icons8-Comments.png" alt="Commenter"> Commenter(<?=$T['commentaires'];?>)</a>
		<br>
	<a href="//twitter.com/intent/tweet?text=<?=urlencode("Télécharger et écouter ".html_entity_decode($T['artiste'].' - '.$T['nom']));?>&amp;url=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']);?>" target="_blank" style="position: relative;top: -10px; font-size: 11pt; cursor: pointer; font-weight: normal;" title="Tweeter ceci"><img style="position: relative; top: 8px;" width="33" height="33" src="<?=ROOT_SANS;?>/css/images/icons8-Twitter.png" alt="Tweeter"></a>
		<script type="text/javascript">
			function fbs_click(){u=location.href;t=document.title;window.open('http://www.facebook.com/sharer.php?u='+encodeURIComponent(u)+'&t='+encodeURIComponent(t),'sharer','toolbar=0,status=0,width=626,height=436');return false;}
		</script>
		<a rel="nofollow" class="sh-face" href="http://www.facebook.com/sharer.php?u=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']);?>" onclick="return fbs_click()" target="_blank">
			<img src="<?=ROOT_SANS;?>/css/images/facebook_paylas.png" alt="Partager sur Facebook">
		</a>
	</div>
</div>
<br>
<div class="divider orange"></div>
<br>
<div class="flow-text container">
	<span>Artiste</span>: 
	<a href="#"> <?=$T['artiste'];?> </a>
	<br>
	<span>Album</span>: 
	<a href="<?=M_ABOUT_SONG.'/'.$T['code_name'];?>"> <?=$T['nom'];?> </a>
	<br><span>Genre</span>: 
	<a href="<?=M_SEARCH_BASE.'?q='.urlencode($T['genre']);?>&amp;content=search&amp;o=date#searchalbums" rel="category tag"><?=$T['genre'];?></a>
	
	<br><br><span>Année</span>: 
		<?=$T['annee'];?>
	<br><span>Nombre de pistes</span>: 
		<?=count(explode(';', $T['id_titres']));?>
	<br><span style="width: auto;">Vues</span>: 
		<?=$T['hits'];?> fois
	
	<br><br><span style="width: auto;">Commentaires</span>: 
		<a href="#comments"><?=$T['commentaires'];?></a>
	<br><span>Uploader</span>: 
		<?=$T['uploader'];?>
	<br>
	&copy; <?=$T['label'];?>
</div>

<!-- <br>
<div class="divider orange"></div> -->
<?php
$same_artist = $connect_bdd->prepare("SELECT * FROM musics WHERE album=? AND moderation=0 ORDER BY piste ASC");
$same_artist -> execute(array($T['code_name']));
$a = 0;
//$cnt1 = $same_artist -> rowCount();
?>
<h2 style="font-size: 24pt;" class="cyan center white-text">TrackList <?=$T['artiste'].' - '. $T['nom'];?></h2>
<ul class="collection">
<?php 
while($res = $same_artist->fetch()){
	//$playTime = explode(':', $sa['duree']);
	$a++;
	?>
	<li class="collection-item avatar">
      <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '65X65', $res['pochette']);?>" alt="" class="circle">
      </a> &nbsp; &nbsp;
      <span class="title">
      	<?=$a;?>. 
        <a class="light-blue-text" href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
          <?=$res['artiste'].' - '.$res['titre'];?>
        </a>
      </span>
      <p> <?=$res['duree'];?> - <?=round($res['taille']/pow(2, 20), 2);?>Mo</p>
  	</li>
<?php }
$same_artist->closeCursor();
?>
</ul>

<ul class="collection with-header">
<li class="collection-header">
	<h4>Albums Par <?=$T['artiste'];?></h4>
</li>
<?php
$the_same_albums = $connect_bdd -> prepare("SELECT * FROM albums WHERE artiste=? AND moderation=0 ORDER BY annee DESC");
$the_same_albums -> execute(array($T['artiste']));
$cnt2 = $the_same_albums -> rowCount();
if($cnt2){
	while ($tsa = $the_same_albums -> fetch()) {
		?>
		<li class="collection-item row">
			<a class="col s4 right-align" title="<?=$tsa['artiste'].' - '.$tsa['nom'].' ('.$tsa['annee'].')';?>" href="<?=M_ABOUT_ALBUM.'/'.$tsa['code_name'];?>">
				<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '100X100', $tsa['pochette']);?>" alt="<?=$tsa['nom'];?>" height="90" width="90">
			</a>
			<div class="col s8 left-align">
			<a href="<?=M_ABOUT_ALBUM.'/'.$tsa['code_name'];?>"><?=$tsa['artiste'].' - '.$tsa['nom'].' ('.$tsa['annee'].')';?></a>
			<br>
			<a href="<?=M_ABOUT_ALBUM.'/'.$tsa['code_name'];?>">
				<img width="61" height="21" alt="Ecouter" src="<?=ROOT_SANS;?>/css/images/filmizle.png">
			</a>
			</div>
		</li>
	<?php }
}else{
	echo "<li class=\"collection-item\"><em>Aucun album</em></li>";
}
$the_same_albums -> closeCursor();
?>
</ul>

<p class="flow-text container">
	<strong><u>Tags</u></strong>: 
	<?php
	    echo "Ecouter $T[artiste] $T[nom] , $T[genre], Telecharger $T[artiste] $T[nom] mp3 320 kbps gratuit, Download $T[artiste] $T[nom] free 320 kbps, $T[artiste] $T[nom] album complet 320 kbps, $T[annee], Nouveautés ".date('Y')." de $T[artiste], mp3 gratuit, aac, m4a, flac, zip, torrent , KeDuSon.com , music, streaming $T[artiste], les sons de $T[label], upload par $T[uploader], direct downolad music, Musicbox.cf Team $T[artiste] $T[nom].mp3 , Index of $T[artiste] mp3 Tous les telechargements de musique sur KeDuSon.com #$T[id]";
	                ?>
</p>
<div>
	<h2 style="font-size: 22pt;" class="white-text center light-blue">Commentaires</h2>
	<form method="post" id="comments" style="padding: 0 0 0 1em;" data-group="album" data-row="<?=$T['code_name'];?>">
		<textarea placeholder="Votre commentaire" style="width: 99%; border-radius: 4px; border: 1px solid grey; padding: 5px;" rows="5" name="texte" id="cmtexte"></textarea>
		<br>
		<button type="submit" style="background: url(<?=ROOT_SANS;?>/css/images/navbar.png) center top repeat; border: 1px solid grey; width: auto; height: 26px; cursor: pointer; color: #CCC;">Commenter</button> &nbsp; <small><em>vous êtes connecté en tant que <strong><?=htmlspecialchars($_SESSION['uname']);?></strong> [<a href="/ajouter">changer</a>]</em></small>
	</form>
	<br>
	<!-- <br> -->
	<?php
        $comms = $connect_bdd -> prepare('SELECT * FROM album_comments WHERE album_cn=?');
        $comms -> execute(array(het($T['code_name'])));
        $nb_coms = $comms -> rowCount();
        $pp=1;
        while($cm = $comms -> fetch()){
            ?>
            <div id="alt" style="padding: 2px 5px; height: auto; background: #B9BABB; box-sizing: border-box; color: black;">
                <a href="#"><?=$cm['auteur'];?></a> 
                <?=nl2br(htmlspecialchars($cm['texte']));?>
                <br>
                <small><i>#<?=$pp;?> - <?=date('d/m/Y \à H:i', $cm['date_post']);?> </i></small>
            </div>
            <div style="height: 3px; width: 100%;"></div>
                <?php
                    $pp++;
                }
            $comms -> closeCursor();
            ?>
</div>
<br>
<h2 style="font-size: 22pt;" class="white-text center light-blue">Suggestions</h2>
<div class="collection">
<?php
$sugs = $connect_bdd->query("SELECT * FROM albums WHERE moderation=0 AND id >= RAND()*( SELECT MAX(id) FROM albums ) ORDER BY id LIMIT 20");
while($sug = $sugs -> fetch()){
	echo '<a class="collection-item" href="'.M_ABOUT_ALBUM.'/'.$sug['code_name'].'">'.$sug['artiste'].' - '. $sug['nom'].' <span class="green-text"> ('.$sug['annee'].') [AC]</span></a>';
}
$sugs->closeCursor();
?>
</div>