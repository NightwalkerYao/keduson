<?php
switch ($_GET['content']) {
	case 'ajouter':
		if(isset($_POST['username'], $_POST['password'])){
			extract($_POST);
			$login = htmlentities($username, ENT_QUOTES);
			$sql = $connect_bdd -> prepare("SELECT pseudo,pass,token,ban FROM membres WHERE pseudo=? OR email=? LIMIT 1");
			$sql -> execute(array($login, $login));
			list($pseudo, $pass, $token, $ban) = $sql -> fetch();
			$sql -> closeCursor();
			if(password_verify($password, $pass)){
				//matched!
				if($ban == 0){
					//not banned yet
					if(isset($remenber)){
						$expiration = time()+60*60*24*30*3; //3mois
						setcookie('membre',$pseudo,$expiration,'/');
						setcookie('token',hash('md5',$token),$expiration,'/');
					}else{
						$expiration = time()-5; //expired
						setcookie('membre',$pseudo,$expiration,'/');
						setcookie('token',hash('md5',$token),$expiration,'/');
					}
					$_SESSION['user'] = $pseudo;
					$_SESSION['uname'] = $pseudo;
					$update = $connect_bdd -> prepare("UPDATE membres SET ip=?, dernier_acces=? WHERE pseudo=? LIMIT 1");
					$update -> execute(array($_SERVER['REMOTE_ADDR'], time(), $pseudo));
					$update -> closeCursor();
				}else{
					$log_error =  'Ce compte est banni actuellement. Revenez plus tard.';
				}
			}else{
				$log_error = "Identifiant ou mot de passe incorrect.";
			}
		}/*else{
			$log_error = "Des données manquent au formulaire transmis";
		}*/
		if(isset($_POST['rusername'], $_POST['rpassword'], $_POST['rpassword2'], $_POST['remail'])){
			$reg_error = [];
			extract($_POST);
			if(!preg_match("#^[a-zA-Z0-9\._\-]{4,25}$#", $rusername))
				$reg_error[] = 'Le pseudo n\'est pas valide.';
			if(strlen($rpassword)<6)
				$reg_error[] = 'Le mot de passe est trop court.';
			if($rpassword2 != $rpassword)
				$reg_error[] = 'Les mots de passe ne correspondent pas.';
			if(!preg_match('#^[a-z0-9.+_-]+@[a-z0-9._-]+\.[a-z0-9]{2,12}$#is', $remail))
				$reg_error[] = 'L\'adresse mail est invalide.';

			if(!count($reg_error)){
				$check_ex = $connect_bdd -> prepare("SELECT COUNT(*) AS nt FROM membres WHERE pseudo=? OR email=? LIMIT 1");
				$check_ex -> execute(array($rusername, $remail));
				list($nt) = $check_ex -> fetch();
				$check_ex -> closeCursor();
				if($nt>0)
					$reg_error[] = 'Identifiants déjà en utilisation.';
				else{
					$tok = md5(uniqid());
					$reg = $connect_bdd -> prepare("INSERT INTO membres(pseudo, pass, email, avatar, token, ip, inscription) VALUES(?,?,?,?,?,?,?)");
					$reg -> execute(array($rusername,password_hash($rpassword, PASSWORD_BCRYPT), $remail, 'default.png', $tok, $_SERVER['REMOTE_ADDR'], time()));
					$reg -> closeCursor();
					$_SESSION['user'] = $rusername;
					$_SESSION['uname'] = $rusername;
				}
			}
		}
		break;
	case 'download':
		if(isset($_GET['id'], $_SERVER['HTTP_REFERER'])){
		    $id = het($_GET['id']);
		    $ref = $_SERVER['HTTP_REFERER'];
		    $the_ref = '/telecharger/'.$id; //must be from here to ddl.
		    
		    //check the HTTP_REFERER before processing to ddl.
		    //if not from the details page, redirect to title's details
		    //else go ddl.
		    if(strpos($ref, $the_ref) !== false){
		        $exist = $connect_bdd -> prepare('SELECT * FROM musics WHERE code_name=? AND moderation=0 LIMIT 1');
		        $exist -> execute(array($id));
		        $found = $exist -> rowCount();
		        $t = $exist -> fetch();
		        $exist -> closeCursor();
		    
		        if($found){
		            $path = 'files/'.$t['nom_fichier'];
		            if(file_exists($path)){
		                $setdl = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE code_name=?');
		                $setdl -> execute(array($id));
		                $setdl -> closeCursor();
		                
		                $ext = pathinfo($t['nom_fichier'], PATHINFO_EXTENSION);
		                $o = '';
		                //$o .= $t['id'];
		                //$o .= '_';
		                $o .= urlencode_2($t['artiste']);
		                $o .= '-';
		                $o .= urlencode_2($t['titre']);
		                $o .= '[KeDuSon.com]';
		                $o .= '.';
		                $o .= $ext;
		                //$o = strip_tags($o);
		            
		                header('Content-Description: File Transfer');
		                header('Content-Type: application/octet-stream');
		                header('Content-Disposition: attachment; filename="'.$o.'"');
		                header('Content-Transfer-Encoding: binary');
		                header('Expires: 0');
		                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		                header('Pragma: public');
		                header('Content-Length: '.filesize($path));
		                readfile($path);
		                exit;
		            }else{
		                die("Ce fichier n'existe plus. Merci de signaler un lien mort aux administrateurs.");
		            }
		        }else{
		            die("Ce fichier n'est pas dans la liste des telechargements autorisés.");
		        }
		    }else{
		        header('Location: '.ROOT_SANS.$the_ref);
		        exit;
		    }
		}else{
		    die("Cette page fonctionne pas comme prévu. Vous avez peut être manqué des trucs.. Revenez demain svp.");
		}
		break;
	case 'artiste':
		if(!isset($_GET['id'])){
			$_GET['content'] = '403';
		}else{
			$_TITRE = 'Artiste :: '. htmlspecialchars($_GET['id']);
			$_META_DESCRIPTION = "Tous les sons et albums de ". htmlspecialchars($_GET['id']).", les nouveautés ".date("Y")." de ". htmlspecialchars($_GET['id'])." sont sur www.KeDuSon.com. Télécharger et écouter gratuitement le meilleur de ". htmlspecialchars($_GET['id'])." , de la musique Africaine et du monde.";
			$_META_KEYWORDS = "artiste,". htmlspecialchars($_GET['id']).",nouveautés ". date("Y").",Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
			$_OG_URL = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$_OG_TITLE = $_TITRE;
			$_OG_DESCRIPTION = $_META_DESCRIPTION;
			$_OG_TYPE= "website";
			$_OG_IMAGE = ROOT_SANS.'/logo-kds.png';
			$_OG_SITE_NAME = 'KeDuSon.com';
		}
		break;
	case 'search': //recherche
		if(!isset($_GET['q'])){
			header('Location:'.ROOT_SANS);
			exit();
		}
		if(isset($_GET['addTo'])){
			if(strlen($_REQUEST['q'])<3)
				exit();

			$out = array();
			$q = htmlentities($_REQUEST['q'], ENT_QUOTES);
			$stmt = "SELECT * FROM musics WHERE MATCH (artiste, titre, album, genre, label) AGAINST (?) AND moderation=0";
			$find = $connect_bdd -> prepare($stmt);
			$find -> execute(array($q));
			$res = $find -> fetchAll(PDO::FETCH_OBJ);
			$find -> closeCursor();
			foreach ($res as $r) {
				// $retour['entrees'][] = $r -> artiste.' - '.$r->titre;
				// $retour['valeurs'][] = $r -> artiste.' '.$r->titre;
				$out[] = str_replace('&#039;', '\'',html_entity_decode($r -> artiste.' - '.$r->titre));
			}
			//print_r($res);

			$stmt2 = "SELECT * FROM albums WHERE MATCH (artiste, nom, label, genre) AGAINST (?) AND moderation=0";
			$find2 = $connect_bdd -> prepare($stmt2);
			$find2 -> execute(array($q));
			$res2 = $find2 -> fetchAll(PDO::FETCH_OBJ);
			$find2 -> closeCursor();
			foreach ($res2 as $r2) {
				// $retour['entrees'][] = $r2 -> artiste.' - '.$r2->nom;
				// $retour['valeurs'][] = $r2 -> artiste.' '.$r2->nom;
				$out[] = str_replace('&#039;', '\'',html_entity_decode($r2 -> artiste.' - '.$r2->nom));
			}
			if(count($out)){
				//echo '<ul><li style="color: blue;">'.implode('</li><li style="color: blue;">',array_slice($out, 0, 10)).'</li></ul>';
				$aout = array_slice($out, 0, 15);
				//echo '<ul>';
				foreach ($aout as $o) {
					echo '<a class="acLinky" style="display:block;" href="'.ROOT_SANS.'/search?q='.urlencode($o).'&content=search">'.htmlspecialchars(strtolower(tronquer($o,38))).'</a>';
				}
				echo '<style>a.acLinky{padding: 1px 11px; font-size:10pt;} a.acLinky:hover{color: #fff; text-decoration: none; background-color: rgba(27, 114, 202, 0.8);}</style>';
			}
			exit();
		}
		if(strlen($_REQUEST['q'])<3)
			$_GET['content'] = '403';
		else{
		if(isset($_GET['navbar'])){ //selection genre depuis Navbar
			switch ($_GET['q']) {
				case 'hip-hop':
					$_GET['q'] = 'Rap / Hip-Hop / RapIvoire / RapFr / RapUS';
					break;
				case 'rnb':
					$_GET['q'] = 'R&B / Soul';
					break;
				case 'folk':
					$_GET['q'] = 'Folk / Traditionnel';
					break;
			}
			$_TITRE = 'Genre :: '. strtoupper(htmlspecialchars($_GET['q']));
			$_META_DESCRIPTION = "Genre de musique : ". strtoupper(htmlspecialchars($_GET['q']))." , Selection dans toutes les listes de morceaux et albums disponibles sur www.keduson.com. Télécharger et écouter gratuitement le meilleur de la musique Africaine et du monde.";
			$_META_KEYWORDS = "genre de musique, ". strtoupper(htmlspecialchars($_GET['q']))." , Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
			$_OG_URL = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$_OG_TITLE = $_TITRE;
			$_OG_DESCRIPTION = $_META_DESCRIPTION;
			$_OG_TYPE= "website";
			$_OG_IMAGE = ROOT_SANS.'/logo-kds.png';
			$_OG_SITE_NAME = 'KeDuSon.com';
		}else{ //recherche normal ou lien depuis page titre.php/album.php
			$_TITRE = 'Recherche :: '. htmlspecialchars($_GET['q']);
			$_META_DESCRIPTION = "Rechercher ". htmlspecialchars($_GET['q'])." dans les listes de morceaux et albums disponibles sur www.keduson.com. Télécharger et écouter gratuitement le meilleur de la musique Africaine et du monde.";
			$_META_KEYWORDS = "Recherche, ". htmlspecialchars($_GET['q'])." , Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
			$_OG_URL = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$_OG_TITLE = $_TITRE;
			$_OG_DESCRIPTION = $_META_DESCRIPTION;
			$_OG_TYPE= "website";
			$_OG_IMAGE = ROOT_SANS.'/logo-kds.png';
			$_OG_SITE_NAME = 'KeDuSon.com';
		}
		}
		break;
	case 'titre': //details sur un titre
		if(!isset($_GET['id'])){
			header('Location:'.ROOT_SANS);
			exit();
		}
		$titre = $connect_bdd -> prepare("SELECT * FROM musics WHERE code_name=? AND moderation=0 LIMIT 1");
		$titre -> execute(array(het($_GET['id'])));
		$cnt = $titre->rowCount();
		$T = $titre->fetch();
		$titre -> closeCursor();
		if(!$cnt){
			$_GET['content'] = '404';
		}else{
			$_TITRE = 'Télécharger '.strtoupper(html_entity_decode($T['artiste'].' - '.$T['titre'])).'.mp3 | Download '.strtoupper(html_entity_decode($T['artiste'].' - '.$T['titre'])).'.mp3';
		    $_META_DESCRIPTION = "$T[artiste] - $T[titre].mp3, Durée: $T[duree], Taille du fichier: ".round($T['taille']/pow(2, 20), 2)."Mo, Date de sortie: $T[annee], Album: $T[album], Genre: $T[genre]. Télécharger et écouter gratuitement le meilleur de la musique Africaine et du monde.";
		    $_META_KEYWORDS = "$T[artiste], $T[titre], $T[album], $T[genre], $T[label], Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
		    $_OG_URL = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		    $_OG_TITLE = $_TITRE;
		    $_OG_DESCRIPTION = $_META_DESCRIPTION;
		    $_OG_TYPE= "website";
		    $_OG_IMAGE = ROOT_SANS.'/covers/'.$T['pochette'];
		    $_OG_SITE_NAME = 'KeDuSon.com';
		}
		break;
	case 'album': //details sur un album
		if(!isset($_GET['id'])){
			header('Location:'.ROOT_SANS);
			exit();
		}
		$titre = $connect_bdd -> prepare("SELECT * FROM albums WHERE code_name=? AND moderation=0 LIMIT 1");
		$titre -> execute(array(het($_GET['id'])));
		$cnt = $titre->rowCount();
		$T = $titre->fetch();
		$titre -> closeCursor();
		if(!$cnt){
			$_GET['content'] = '404';
		}else{
			$stv = 'UPDATE albums SET hits=hits+1 WHERE id='.intval($T['id']);
			$setvues = $connect_bdd->query($stv);
			$setvues->closeCursor();
			$_TITRE = 'Détails de l\'album :: '.strtoupper(html_entity_decode($T['artiste'].' - '.$T['nom'])).' ('.$T['annee'].')';
		    $_META_DESCRIPTION = "$T[artiste] - $T[nom], Nombre de morceaux: ".(count(explode(';', $T['id_titres']))).", Date de sortie: $T[annee], label: $T[label], Genre: $T[genre]. Télécharger et écouter gratuitement le meilleur de la musique Africaine et du monde.";
		    $_META_KEYWORDS = "$T[artiste], $T[nom], $T[annee], $T[genre], $T[label], Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
		    $_OG_URL = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		    $_OG_TITLE = $_TITRE;
		    $_OG_DESCRIPTION = $_META_DESCRIPTION;
		    $_OG_TYPE= "website";
		    $_OG_IMAGE = ROOT_SANS.'/covers/'.$T['pochette'];
		    $_OG_SITE_NAME = 'KeDuSon.com';
		}
		break;
	default:
		# code...
		break;
}
?>