<?php
    function load_timer() {
        $temps = explode(' ',microtime());
        return $temps[0]+$temps[1];
    }
    $startTime = load_timer();
	
    try { $connect_bdd = new PDO('mysql:host=localhost;dbname=kds','root',''); }
	catch (Exception $e)
	{die ('ERREUR: '.$e->getMessage()); }
    $connect_bdd -> exec("SET NAMES utf8");
    
    session_start();
    define("PHP_ROOT", $_SERVER['DOCUMENT_ROOT']."/keduson");
    define("ROOT_SANS", "http://localhost/keduson");
    define("ABOUT_SONG", ROOT_SANS."/page/song");
    define("ABOUT_ALBUM", ROOT_SANS."/page/album");
    define("ABOUT_ARTIST", ROOT_SANS."/page/artist");
    define("DL_LINK", ROOT_SANS."/link/ddl");
    define("SEARCH_BASE", ROOT_SANS."/page/search");
    //mobiles
    define("MOBILE_BASE", "http://keduson.com/mobile"); //default web 4 mobile
    define("M_ABOUT_SONG", MOBILE_BASE."/page/song");
    define("M_ABOUT_ALBUM", MOBILE_BASE."/page/album");
    define("M_ABOUT_ARTIST", MOBILE_BASE."/page/artist");
    define("M_DL_LINK", MOBILE_BASE."/link/ddl");
    define("M_SEARCH_BASE", MOBILE_BASE."/page/search");
//set new username
function change_my_uname($old, $nvo){
    $old = htmlentities($old, ENT_QUOTES);
    $nvo = htmlentities($nvo, ENT_QUOTES);
    global $connect_bdd;
//     $existe = $connect_bdd -> prepare('SELECT COUNT(*) AS ccc FROM live_stats WHERE username=?');
//     $existe -> execute(array($old)) or die('erreur');
//     list($cc) = $existe -> fetch();
//     $existe -> closeCursor();
//     if($cc){
        $ch_in_live = $connect_bdd -> prepare('UPDATE live_stats SET username=? WHERE username=? LIMIT 1');
        $ch_in_live -> execute(array($nvo, $old));
        $count = $ch_in_live -> rowCount();
        $ch_in_live -> closeCursor();
        if(intval($count)){
            $_SESSION['uname'] = $nvo;
            setcookie('instant_name', $nvo, time()+(3*365*24*60*60), '/', false, true);
            return true;
        }
        else
            return false;
}

//new user comes
function new_session(){
    global $connect_bdd;
    $uname = '';
    $set = false;
    $f = 'php/unames.txt';
    $op = fopen($f, 'r');
    $re = fread($op, filesize($f));
    fclose($op);
    $list = explode(';', $re);
    $nb = count($list);
    $nb--;
    $index = mt_rand(0, $nb);
    $uname = $list[$index];

    $_SESSION['uname'] = $uname; //log session
    $log = $connect_bdd -> prepare('INSERT INTO live_stats(ip,username,page,start_stamp) VALUES(:ip, :user, :pg, :strt)');
    $log -> execute(array('ip'=>$_SERVER['REMOTE_ADDR'], 'user'=> htmlentities($uname, ENT_QUOTES), 'pg'=> $_SERVER['REQUEST_URI'], 'strt'=> time()));
    $log -> closeCursor();
    //log cookies
    if(!isset($_COOKIE['instant_name']))
        setcookie('instant_name', $uname, time()+(3*365*24*60*60), '/', false, true);
    else
        setcookie('instant_name', $uname, time()+(3*365*24*60*60), '/', false, true); //hum!
    $_SESSION['uname'] = $uname;
    return $uname;
}

//clean up inactive sessions
function clean_up_sessions(){
    global $connect_bdd;
    $min = time()-(7*60); //7mins to die!
    $clean = $connect_bdd -> prepare('DELETE FROM live_stats WHERE end_stamp<:min');
    $clean -> execute(array('min' => $min));
    $clean -> closeCursor();
    return true;
}

//log my location
function log_my_loc($user, $page, $checkbefore = false){
    global $connect_bdd;
    if($checkbefore){
        $get = $connect_bdd -> prepare("SELECT COUNT(*) FROM live_stats WHERE username=?");
        $get -> execute(array(htmlentities($user, ENT_QUOTES)));
        list($ct) = $get -> fetch();
        $get -> closeCursor();

        if(intval($ct) == 0){
            $log = $connect_bdd -> prepare('INSERT INTO live_stats(ip,username,page,start_stamp) VALUES(:ip, :user, :pg, :strt)');
            $log -> execute(array('ip'=>$_SERVER['REMOTE_ADDR'], 'user'=> htmlentities($user, ENT_QUOTES), 'pg'=> $_SERVER['REQUEST_URI'], 'strt'=> time()));
            $log -> closeCursor();
        }
    }
    
    $ch_in_live = $connect_bdd -> prepare('UPDATE live_stats SET page=?, end_stamp=? WHERE username=?');
    $ch_in_live -> execute(array($page,time(), $user));
    $ch_in_live -> closeCursor();
    clean_up_sessions();
};

//update counter
function counter_me($count=true){
    $mod = ($count ? 'r+' : 'r');
    $cf = 'Huntr.counter';
    $op = fopen($cf, $mod);
    $re = fread($op, filesize($cf));
    $re = intval($re);
    if($count===true){
        $re++;
        fseek($op, 0);
        fwrite($op, $re);
    }
    fclose($op);
    return $re;
}
function tronquer($texte,$long){
    if(strlen(trim($texte)) == 0)
        return "[ v i d e ]";
    if(strlen($texte) <= $long)
        return $texte;
    return substr($texte, 0, $long).' ...';
}
function urlencode_2($texte, $ci=true, $decode=true){
    $texte = strtr(
        $texte,
        "ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ",
        "aaaaaaaaaaaaooooooooooooeeeeeeeecciiiiiiiiuuuuuuuuynn"
    );
    if($decode){
        $texte = str_replace('#039;', '', $texte); // le single quote
        $texte = html_entity_decode($texte);
    }
    if($ci)
        $texte = strtolower($texte);
    //$texte = str_replace(array('à', 'ä', 'æ', 'â', 'ǎ') , 'a', $texte);
    //$texte = str_replace(array('é', 'è','ë', 'ê', 'ě'), 'e',  $texte);
    //$texte = str_replace(array('ï', 'î'), 'i', $texte);
    //$texte = str_replace(array('ô', 'ö', 'Ø'), 'o', $texte);
    //$texte = str_replace(array('ù', 'û', 'ü'), 'u', $texte);
    //$texte = str_replace(array('ç', 'ĉ'), 'c', $texte);
    $texte = preg_replace("#[^a-z0-9-]#i", '-', $texte);
    while(strpos($texte, '--') !== false)
        $texte = str_replace('--', '-', $texte);
    if(substr($texte, -1) === '-')
        $texte = substr($texte, 0, strlen($texte)-1); //suppr le tiret de la fin
    if(substr($texte, 0, 1) === '-')
        $texte = substr($texte, 1);
    return $texte;
}
function het($t){
    return htmlentities($t, ENT_QUOTES);
}
//main script
$_TITRE = preg_replace('#https?://#i','',strtoupper(ROOT_SANS)).' - Ecoute &amp; Téléchargements de musiques';
$_META_DESCRIPTION = "Télécharger et écouter gratuitement le meilleur de la musique Africaine et du monde. Vous êtes artiste? Ajoutez votre musique gratuitement et facilement ici.";
$_META_KEYWORDS = "Téléchargement de musique gratuite,rap,hip hop,reggae,couper decaler,zouglou,afrobeat,afropop,etc en mp3,m4a,zip,torrent,flac";
$_OG_URL = $_SERVER['REQUEST_URI'];
$_OG_TITLE = $_TITRE;
$_OG_DESCRIPTION = $_META_DESCRIPTION;
$_OG_TYPE= "website";
$_OG_IMAGE = ROOT_SANS.'/logo-kds.png';
$_OG_SITE_NAME = 'KeDuSon.com';
if(isset($_GET['content'])){
	include_once PHP_ROOT.'/php/pre-processor.php';
}

// //the session
if(!isset($_SESSION['uname'])){
    if(isset($_COOKIE['instant_name'])){
        $_SESSION['uname'] = htmlentities($_COOKIE['instant_name'], ENT_QUOTES);
        log_my_loc($_SESSION['uname'], $_SERVER['REQUEST_URI'], true); //log current page
    }else{
        $sess1 = new_session(); //start new session
    }
}else
    log_my_loc($_SESSION['uname'], $_SERVER['REQUEST_URI'], true); //log current page

?>
