<?php 
$retour = array();
// $retour['entrees'] = array();
// $retour['valeurs'] = array();
$out = array();
$avt = array();
if(isset($_REQUEST['q'])){
	require_once('../config.php');
	$q = htmlentities($_REQUEST['q'], ENT_QUOTES);
		$stmt = "SELECT * FROM musics WHERE MATCH (artiste, titre, album, genre, label) AGAINST (?) AND moderation=0";
		$find = $connect_bdd -> prepare($stmt);
		$find -> execute(array($q));
		$res = $find -> fetchAll(PDO::FETCH_OBJ);
		$find -> closeCursor();
		foreach ($res as $r) {
			// $retour['entrees'][] = $r -> artiste.' - '.$r->titre;
			// $retour['valeurs'][] = $r -> artiste.' '.$r->titre;
			$out[] = str_replace('&#039;', ' ',html_entity_decode($r -> artiste.' '.$r->titre));
			$avt[] = str_replace('500X500', '65X65', $r->pochette);
		}
		//print_r($res);

		$stmt2 = "SELECT * FROM albums WHERE MATCH (artiste, nom, label, genre) AGAINST (?) AND moderation=0";
		$find2 = $connect_bdd -> prepare($stmt2);
		$find2 -> execute(array($q));
		$res2 = $find2 -> fetchAll(PDO::FETCH_OBJ);
		$find2 -> closeCursor();
		foreach ($res2 as $r2) {
			// $retour['entrees'][] = $r2 -> artiste.' - '.$r2->nom;
			// $retour['valeurs'][] = $r2 -> artiste.' '.$r2->nom;
			$out[] = str_replace('&#039;', ' ',html_entity_decode($r2 -> artiste.' '.$r2->nom));
			$avt[] = str_replace('500X500', '65X65', $r->pochette);
		}
}

// echo json_encode($retour);
if(count($out)){
    $print = [];
    for($i=0; $i<count($out); $i++){
        $print[$out[$i]] = ROOT_SANS.'/covers/'.$avt[$i];
    }
}
echo json_encode($print);
