<?php
    $out = array('end'=>'fail');
    $Dir = '../../covers/'.date('Y').'/'.date('m'); //adapte au mois et l'annee auto.

    if(isset($_FILES['cover']) && $_FILES['cover']['error'] == 0){
        $filename = strip_tags($_FILES['cover']['name']);
        $ext = pathinfo($filename,PATHINFO_EXTENSION);
        $store_name = date('YmdHis').'_'.uniqid();
        $store_name .= '.'.$ext;
    
        $allowed = array('jpg','jpeg','png','gif');
        if(in_array(strtolower($ext), $allowed)){
            if(!is_dir($Dir))
                mkdir($Dir, 0777, true);
            $dir_path = $Dir.'/'.$store_name;
            if(move_uploaded_file($_FILES['cover']['tmp_name'], $dir_path)){
            // good ops here
                require("../gd.php");
                $rez = Resolution($dir_path);
                if($rez["width"]<250 OR $rez["height"]<250){
                    $out['end'] = 'fail';
                    $out['message'] = "L'image est trop petite. Il faut au moins 250x250";
                }else{
                    $t500 = Redim($store_name,500,500,$Dir.'/');
                    $t500 = Tag('tag.png',$t500,$Dir.'/');
                    $t200 = Redim($store_name,200,200,$Dir.'/');
                    $t100 = Redim($store_name,100,100,$Dir.'/');
                    $t65 = Redim($store_name,65,65,$Dir.'/');
                    $tjplayer = Redim($store_name,640,360,$Dir.'/');
                    $out['path'] = date('Y').'/'.date('m').'/'.$t500;
                    $out['end'] = 'success';
                }
                @unlink($dir_path);
            }else{
                $out["end"]="fail";
                $out["message"]="Une erreur s'est produite pendant la copie du fichier sur le serveur. Veillez reessayer. Si le problème persiste, contactez l'administration.";
            }
        }else{
            $out["end"]="fail";
            $out["message"]="Le fichier soumis n'est pas dans la liste des types autorisés. Merci de charger un fichier type image.";
        }
    }elseif(isset($_POST['pic'], $_POST['zone']) && file_exists('../../covers/'.strip_tags($_POST['pic']))){ // file from album cover in the zip
        $filename = '../../covers/'.strip_tags($_POST['pic']);
        $ext = pathinfo($filename,PATHINFO_EXTENSION);
        $store_name = $filename;
    
        $allowed = array('jpg','jpeg','png','gif');
        if(in_array(strtolower($ext), $allowed)){
            require("../gd.php");
            $rez = Resolution($store_name);
            if($rez["width"]<250 OR $rez["height"]<250){
                $out['end'] = 'fail';
                $out['message'] = "L'image est trop petite. Il faut au moins 250x250";
            }else{
                $t500 = Redim($store_name,500,500,'');
                $t500 = Tag('tag.png', $t500,'../../covers/');
                $t200 = Redim($store_name,200,200,'');
                $t100 = Redim($store_name,100,100,'');
                $t65 = Redim($store_name,65,65,'');
                $tjplayer = Redim($store_name,640,360,'');
                $out['path'] = str_replace('../../covers/', '', $t500);
                $out['end'] = 'success';
                $out['zone'] = $_POST['zone'];
            }
            @unlink($store_name);
        }else{
            $out["end"]="fail";
            $out["message"]="Le fichier soumis n'est pas dans la liste des types autorisés. Merci de charger un fichier type image.";
        }
    }elseif(isset($_POST['pochPath'], $_POST['base']) && file_exists('../../files/'.$_POST['pochPath'])){ // file from album cover in uploaded directory
        $filename = '../../files/'.$_POST['pochPath'];
        $ext = pathinfo($filename,PATHINFO_EXTENSION);
        $nam = pathinfo($filename,PATHINFO_FILENAME).'.'.$ext;
            if(copy('../../files/'.$_POST['pochPath'], '../../covers/'.$nam)){
            $store_name = '../../covers/'.$nam;
        
            $allowed = array('jpg','jpeg','png','gif');
            if(in_array(strtolower($ext), $allowed)){
                require("../gd.php");
                $rez = Resolution($store_name);
                if($rez["width"]<250 OR $rez["height"]<250){
                    $out['end'] = 'fail';
                    $out['message'] = "L'image est trop petite. Il faut au moins 250x250";
                }else{
                    $t500 = Redim($store_name,500,500,'');
                    $t500 = Tag('tag.png',$t500,'../../covers/');
                    $t200 = Redim($store_name,200,200,'');
                    $t100 = Redim($store_name,100,100,'');
                    $t65 = Redim($store_name,65,65,'');
                    $tjplayer = Redim($store_name,640,360,'');
                    $out['path'] = str_replace('../../covers/', '', $t500);
                    $out['end'] = 'success';
                    //$out['zone'] = $_POST['zone'];
                }
                @unlink($store_name);
            }else{
                $out["end"]="fail";
                $out["message"]="Le fichier soumis n'est pas dans la liste des types autorisés. Merci de charger un fichier type image.";
            }
        }else{
            $out["end"]="fail";
            $out["message"]="La copie de l'image ne s'est pas bien achevee.";
        }
    }else{
        $out["end"]="fail";
        $out["message"]="L'upload du fichier ne s'est pas terminé correctement. Merci de reprendre.";
    }

echo json_encode($out);

?>
