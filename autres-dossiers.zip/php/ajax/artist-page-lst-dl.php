<?php 

$out = array('end'=>'fail', 'message'=>'Could not process your request now.');
require_once '../config.php';

if(isset($_POST['elts'])){
    $elts = $_POST['elts'];
    $files = array();
    $names = array();
    
    
    foreach($elts as $elt){
        $sh = $connect_bdd -> prepare('SELECT artiste, titre FROM musics WHERE nom_fichier=? AND moderation=0 LIMIT 1');
        $sh -> execute(array(htmlentities($elt, ENT_QUOTES)));
        $c = intval($sh -> rowCount());
        if($c){
            $res = $sh -> fetch();
            $files[] = $elt;
            $names[] = urlencode_2(html_entity_decode($res['artiste']).'-'.html_entity_decode($res['titre']));
            $art = $res['artiste'];
        }
        $sh -> closeCursor();
    }
    
    if(count($files)){
        $out['end'] = 'succes';
        $out['artist'] = urlencode_2(html_entity_decode($art));
        $out['message'] = 'all done';
        $out['filelist'] = implode(';', $files);
        $out['filenames'] = implode('|||', $names);
        $out['nbFiles'] = count($files);
    }
}

echo json_encode($out);
