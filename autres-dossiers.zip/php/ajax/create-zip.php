<?php 
$out = array('end'=> 'fail', 'message'=>"Erreur inattendue. Veillez essayer à nouveau.#1");

require_once '../config.php';
//the function

function create_zip($files = array(),$destination = '',$overwrite = false) {
	//if the zip file already exists and overwrite is false, return false
	if(file_exists($destination) && !$overwrite) { return false; }
	//vars
	$valid_files = array();
	//if files were passed in...
	if(is_array($files)) {
		//cycle through each file
		foreach($files as $file) {
			//make sure the file exists
			if(file_exists($file)) {
				$valid_files[] = $file;
			}
		}
	}
	//if we have good files...
	if(count($valid_files)) {
		//create the archive
		$zip = new ZipArchive();
		if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
			return false;
		}
		//add the files
		foreach($valid_files as $file) {
			$zip->addFile($file,$file);
		}
		//debug
		//echo 'The zip archive contains ',$zip->numFiles,' files with a status of ',$zip->status;
		
		//close the zip -- done!
		$zip->close();
		
		//check to make sure the file exists
		return file_exists($destination);
	}
	else
	{
		return false;
	}
}
//end of function


if(isset($_POST['filelist'], $_POST['filenames'], $_POST['nbFiles'])){

    //name of the archive to be created
    $dlname = 'archive-'.date('YmdHis');
    $directory = 'dir'; //temp dir for files to zip
    if(isset($_POST['artist'])){
        $dlname = urlencode_2($_POST['artist'].'-'.$_POST['nbFiles']).'-morceaux-'.mt_rand(0,99).'.zip';
        $directory = urlencode_2($_POST['artist']);
    }
    
    if(isset($_POST['album'])){
        $dlname = urlencode_2($_POST['album']).'.zip';
        $directory = urlencode_2($_POST['album']);
    }
    
    //dir to store all zips
    if(!is_dir('../../zipped'))
        mkdir('../../zipped', 0777);
    
    //deleted log dir
    if(!is_dir('../../deleted_log'))
        mkdir('../../deleted_log', 0777);
        
    //delete old archives
    $existing_archs = scandir('../../zipped/');
    foreach($existing_archs as $ea){
        if($ea != '.' && $ea != '..' && $ea != 'index.php' && $ea != 'home.php' && $ea != '.htaccess' && $ea != 'index.html'){
            if(intval(filemtime('../../zipped/'.$ea)) < (time()-60*60*3)){
                if(@unlink('../../zipped/'.$ea)){
                    $dlfile = '../../deleted_log/deleting_zips.txt';
                    if(file_exists($dlfile) && filesize($dlfile)>=500000){
                        rename($dlfile, '../../deleted_log/deleted_zips-'.date('YmdHis').'.log');
                    }
                    $dlop = fopen($dlfile, 'a+');
                    fwrite($dlop, date('d/m/Y H:i:s').' '.$ea.' deleted \r\n');
                    fclose($dlop);
                }
            }
        }
    }

    $filz = explode(';', $_POST['filelist']);
    $namz = explode('|||', $_POST['filenames']);
    
    //if the same file already exists and not expired (old of 4h)
    if(file_exists('../../zipped/'.$dlname)){
        foreach($filz as $f){
            $hit = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE nom_fichier=? LIMIT 1');
            $hit -> execute(array(htmlentities($f, ENT_QUOTES)));
            $hit -> closeCursor();
        }
        $out['end'] = 'succes';
        $out['message'] = '';
        $out['archName'] = $dlname;
        $out['archSize'] = (round(@filesize('../../zipped/'.$dlname)/bcpow(2,20),2)).'Mo';
        $out['link'] = ROOT_SANS.'/zipdl/'.str_replace('.zip', '', $dlname);
    }else{ //create the archive file
        if(!is_dir('./'.$directory))
            mkdir('./'.$directory, 0777);
            
        $true_files = array();
        
        //copy files to the temp dir
        for($i=0; $i<count($filz); $i++){
            $filz[$i] = str_replace('../','',$filz[$i]); //do no go to top dir. sec
                if(file_exists('../../files/'.$filz[$i])){
                    $ext = '.'.pathinfo($filz[$i], PATHINFO_EXTENSION);
                    @copy('../../files/'.$filz[$i], './'.$directory.'/'.$namz[$i].$ext);
                    $true_files[] = $directory.'/'.$namz[$i].$ext;
                }
            //}
            
            //set hit+1 (downloaded)
            $hit = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE nom_fichier=? LIMIT 1');
            $hit -> execute(array(htmlentities($filz[$i], ENT_QUOTES)));
            $hit -> closeCursor();
        }
        
        //case album, do hit+1
        if(isset($_POST['aCN'])){
            $albhit = $connect_bdd -> prepare('UPDATE albums SET hits=hits+1 WHERE code_name = ? LIMIT 1');
            $albhit -> execute(array(htmlentities($_POST['aCN'], ENT_QUOTES)));
            $albhit -> closeCursor();
        }
        
        if(count($true_files) && create_zip($true_files, '../../zipped/'.$dlname, false)){
            //clean trashes
            foreach($true_files as $tf){
                @unlink($tf);
            }
            @rmdir('./'.$directory);
            
            $out['end'] = 'succes';
            $out['message'] = '';
            $out['archName'] = $dlname;
            $out['archSize'] = (round(@filesize('../../zipped/'.$dlname)/bcpow(2,20),2)).'Mo';
            $out['link'] = ROOT_SANS.'/zipdl/'.str_replace('.zip', '', $dlname);
        }else{
            $out['message'] = "La création de l'archive a échoué. Veillez essayer à nouveau.";
        }
    }
}

echo json_encode($out);
