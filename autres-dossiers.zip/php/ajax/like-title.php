<?php
require_once '../config.php';
$out = array('end'=>'fail', 'message'=>'');

//single.like || single.unlike
if(isset($_REQUEST['elt'], $_REQUEST['action'])){
    $elt = het($_REQUEST['elt']);
    $do = ($_REQUEST['action'] == 'like' ? '+1' : '+1'); //corrected !!
    $col = ($_REQUEST['action'] == 'like' ? 'likes' : 'dislikes');
    
    $sql = 'UPDATE musics SET '.$col.'='.$col.$do.' WHERE code_name=? LIMIT 1';
    $lik = $connect_bdd -> prepare($sql);
    $lik -> execute(array($elt));
    $lik -> closeCursor();
    
    $s = 'SELECT '.$col.' FROM musics WHERE code_name=? LIMIT 1';
    $getlks = $connect_bdd -> prepare($s);
    $getlks -> execute(array($elt));
    list($lk) = $getlks -> fetch();
    $f = $getlks -> rowCount();
    $getlks -> closeCursor();
    
    if($f){
        $out['end'] = 'succes';
        $out['likes'] = intval($lk);
    }else{
        $out['message'] = "Le titre n'existe plus.";
    }
}

//album.like || album.unlike
if(isset($_REQUEST['album'], $_REQUEST['do'])){
    $elt = het($_REQUEST['album']);
    $do = ($_REQUEST['do'] == 'like' ? '+1' : '+1'); //corrected !!
    $col = ($_REQUEST['do'] == 'like' ? 'likes' : 'dislikes');
    
    $sql = 'UPDATE albums SET '.$col.'='.$col.$do.' WHERE code_name=? LIMIT 1';
    $lik = $connect_bdd -> prepare($sql);
    $lik -> execute(array($elt));
    $lik -> closeCursor();
    
    $s = 'SELECT '.$col.' FROM albums WHERE code_name=? LIMIT 1';
    $getlks = $connect_bdd -> prepare($s);
    $getlks -> execute(array($elt));
    list($lk) = $getlks -> fetch();
    $f = $getlks -> rowCount();
    $getlks -> closeCursor();
    
    if($f){
        $out['end'] = 'succes';
        $out['likes'] = intval($lk);
    }else{
        $out['message'] = "Le titre n'existe plus.";
    }
}

echo json_encode($out);
?>
