<?php 
$out = array('end'=>'fail', 'message'=>'Could not process your request now. Try again later.');
require_once '../config.php';
if(isset($_POST['uname'])){
    if(change_my_uname($_SESSION['uname'], $_POST['uname'] )){
        $out['end'] = 'succes';
        unset($out['message']);
    }else{
        $out['message'] = 'Setting failed: user "'.$_SESSION['uname'].'" does not exist.';
    }
}
echo json_encode($out);
