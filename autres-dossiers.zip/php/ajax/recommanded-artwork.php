<?php
$out = array('end'=>'fail', 'message'=>'');
$collect = array();

require_once('../config.php');

if(isset($_POST['artist'], $_POST['album'])){ //process with 2
    $artist = htmlentities($_POST['artist'], ENT_QUOTES);
    $album = htmlentities($_POST['album'], ENT_QUOTES);
    
    $get = $connect_bdd->prepare("SELECT DISTINCT(pochette) FROM musics WHERE artiste LIKE :artiste OR album LIKE :album ORDER BY id DESC LIMIT 4");
    $get -> execute(array("artiste"=>'%'.$artist.'%', "album"=>'%'.$album.'%'));
    //$cnt = $get -> rowCount();
    while(list($poch) = $get-> fetch()){
        $collect[] = $poch;
    }
    $get -> closeCursor();
    $out['end'] = 'success';
    
}elseif(isset($_POST['artist']) && !isset($_POST['album']) && count($collect)<4){
    $artist = htmlentities($_POST['artist'], ENT_QUOTES);
    //$album = htmlentities($_POST['album'], ENT_QUOTES);
    
    $get = $connect_bdd->prepare("SELECT DISTINCT(pochette) FROM musics WHERE artiste LIKE :artiste ORDER BY id DESC LIMIT 4");
    $get -> execute(array("artiste"=>'%'.$artist.'%'));
    //$cnt = $get -> rowCount();
    while(list($poch) = $get-> fetch()){
        $collect[] = $poch;
    }
    $get -> closeCursor();
    $out['end'] = 'success';
    
}elseif(!isset($_POST['artist']) && isset($_POST['album']) && count($collect)<4){
    //$artist = htmlentities($_POST['artist'], ENT_QUOTES);
    $album = htmlentities($_POST['album'], ENT_QUOTES);
    
    $get = $connect_bdd->prepare("SELECT DISTINCT(pochette) FROM musics WHERE album LIKE :album ORDER BY id DESC LIMIT 4");
    $get -> execute(array("album"=>'%'.$album.'%'));
    //$cnt = $get -> rowCount();
    while(list($poch) = $get-> fetch()){
        $collect[] = $poch;
    }
    $get -> closeCursor();
    $out['end'] = 'success';
    
}else{
    $out['message'] = "Certaines donnees requises manquent dans le corps de la requete.";
}

//outprinting
$a = 1;
foreach($collect as $c){
    if(stripos($c, 'default') === FALSE){
        $ct = explode('-',$c);
        $et = explode('.', $c);
        $racine = $ct[0];
        $ext = $et[count($et)-1];
        
        $out["pochette$a"] = $racine.'-65X65.'.$ext;
        $a++;
    }
}

if(isset($_REQUEST['reqid']))
    $out['rid'] = intval($_REQUEST['reqid']);
    
echo json_encode($out);
