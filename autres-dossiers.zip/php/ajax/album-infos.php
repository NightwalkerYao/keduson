<?php
$out = array('end'=>'fail', 'message'=>'');
if(isset($_POST['album'], $_POST['artiste'])){
    require_once('../config.php');
    $artiste = htmlentities($_POST['artiste'], ENT_QUOTES);
    $album = htmlentities($_POST['album'], ENT_QUOTES);
    
    //getting from db
    $q = $connect_bdd -> prepare("SELECT * FROM albums WHERE code_name=? AND moderation=0 LIMIT 1");
    $q -> execute(array($album));
    $c = intval($q->rowCount());
    $res = $q -> fetch();
    $q->closeCursor();
    
    if($c==1){
        //get title's infos - all
        $out['end'] = 'success';
        $out['albumName'] = $res['nom'];
        $out['albumCN'] = $res['code_name']; //code name -- CN
        $out['artist'] = $res['artiste'];
        $out['artistCN'] = urlencode_2($res['artiste']);
        $out['year'] = $res['annee'];
        $out['label'] = $res['label'];
        $out['genre'] = $res['genre'];
        $out['artwork'] = $res['pochette'];
        $out['uploader'] = $res['uploader'];
        $out['dls'] = $res['hits'];
        $out['likes'] = $res['likes'];
        $out['dislikes'] = $res['dislikes'];
        $out['comments'] = $res['commentaires'];
        
        $t_list = $res['id_titres'];
        $tids = explode(';', $t_list);
        $out['countTitle'] = count($tids);
        $a=1; //$b=1;
        $out['tracks'] = array();
        
        $concated_li = "";
        
        foreach($tids as $k){
            $ft = $connect_bdd -> prepare("SELECT * FROM musics WHERE id=? AND moderation=0 LIMIT 1");
            $ft -> execute(array(intval($k)));
            $t = $ft -> fetch();
            $ft -> closeCursor();
            $out['tracks']['track'.$a] = array();
            $out['tracks']['track'.$a]['filename']=$t['nom_fichier'];
            $out['tracks']['track'.$a]['CN'] = $t['code_name'];
            $out['tracks']['track'.$a]['title'] = $t['titre'];
            $out['tracks']['track'.$a]['no'] = $t['piste'];
            $out['tracks']['track'.$a]['duration'] = $t['duree'];
            $out['tracks']['track'.$a]['size'] = $t['taille'];
            $out['tracks']['track'.$a]['hits'] = $t['hits'];
            $out['tracks']['track'.$a]['likes'] = $t['likes'];
            $out['tracks']['track'.$a]['dislikes'] = $t['dislikes'];
            $out['tracks']['track'.$a]['comments'] = $t['commentaires'];
            
            $concated_li .= '<li> <img src="'.ROOT_SANS.'/img/icones/icons8-Circled Play.png" alt="" class="icon inlist"> <a href="'.ROOT_SANS.'/i/'.$t['code_name'].'.htm" class="tracklink"> '.$t['titre'].' </a> <br> <span class="trackduration"> '.$t['duree'].' </span> &nbsp;<span class="trackdls"> '.$t['hits'].' </span> &nbsp;<span class="tracklk"> '.$t['likes'].' </span> &nbsp;<span class="trackdlk"> '.$t['dislikes'].' </span> &nbsp;<span class="trackcomm"> '.$t['commentaires'].' </span> </li>';
            
            $a++;
        }
        
        //get count artist's titles
        $at = $connect_bdd -> prepare('SELECT COUNT(*) AS n FROM musics WHERE artiste=? AND moderation=0');
        $at -> execute(array(htmlentities($out['artist'], ENT_QUOTES)));
        list($n) = $at -> fetch();
        $at -> closeCursor();
        
        $out['cated_liz'] = $concated_li;
        $out['artistNbSongs'] = $n;
    }else{
        $out['message'] = "Cet album n'existe plus dans les enregistrements.";
    }
}else{
    $out['message'] = "Des donnees requises n'ont pas ete transmises a cette page.";
}

echo json_encode($out);
