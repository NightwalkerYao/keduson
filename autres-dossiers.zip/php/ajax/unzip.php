<?php 
$out = array('end'=>'fail','message'=>'Could not proccess your request at this time. Please try again later');
require_once '../config.php';

if(isset($_POST['upload_id'], $_POST['upload_filename'], $_POST['upload_outname'])){
    $id = intval($_POST['upload_id']);
    $filename = $_POST['upload_filename'];
    $truefile = $_POST['upload_outname'];
    $out['cover'] = '';
    $out['upload'] = $id;
    
    if(isset($_POST['reqid']))
        $out['reqid'] = intval($_POST['reqid']);
                    
    $archive_content = array();
    $original_fns = array();
    $base_dir = '../../temp_upz/';
    if(file_exists($base_dir.$truefile)){
        $path = $base_dir.$truefile;
        $zip = new ZipArchive;
        if ($zip->open($path) === true) {
            for($i = 0; $i < $zip->numFiles; $i++) {
                $fn = $zip->getNameIndex($i);
                $fileinfo = @pathinfo($fn);
                $gud_exts = array('mp3', 'aac', 'm4a', 'wav', 'ogg', 'flac', 'mid');
                if(in_array(strtolower(@$fileinfo['extension']), $gud_exts)){
                    $f = uniqid().'.'.$fileinfo['extension'];
                    if(copy("zip://".$path."#".$fn, $base_dir.$f)){
                        $archive_content[] = $f;
                        $original_fns[] = $fn;
                    }
                }
                $imgs = array('png', 'jpg', 'jpeg', 'gif'); //use it as cover
                if(in_array(strtolower(@$fileinfo['extension']), $imgs)){
                    $p = date('YmdHis').'_'.uniqid().'.'.$fileinfo['extension'];
                    if(!is_dir('../../covers/'.date('Y').'/'.date('m')))
                        mkdir('../../covers/'.date('Y').'/'.date('m'),0777, true)
                    if(copy("zip://".$path."#".$fn, '../../covers/'.date('Y').'/'.date('m').'/'.$p)){
                        $out['cover'] = date('Y').'/'.date('m').'/'.$p;
                    }
                }
            }
            $zip->close();
            @unlink($path);
            if(count($archive_content)){
                $out['message'] = '';
                $out['archive'] = $truefile;
                $out['end'] = 'succes';
                $out['files'] = $archive_content;
                $out['fnames'] = $original_fns;
                $out['nbFiles'] = count($archive_content);
                $out['original_file'] = $filename;
            }
        }else{
            $out['message'] = 'Ouverture de l\'archive échouée. Elle est peut être corrompue.';
        }
    }else{
        $out['message'] = 'Cette archive n\'existe pas sur ce serveur. Elle a peut être été écrasée. '; 
    }
}

echo json_encode($out);
