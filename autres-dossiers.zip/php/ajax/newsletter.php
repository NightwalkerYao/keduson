<?php 
if(isset($_REQUEST['yourAddr'])){
	//extract($_REQUEST);
	if(preg_match('#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z0-9]{2,15}$#is', $_REQUEST['yourAddr'])){
		require_once '../config.php';
		$gex = $connect_bdd -> prepare('SELECT COUNT(*) AS cc FROM newsletter WHERE addr=?');
		$gex -> execute(array(htmlentities($_REQUEST['yourAddr'], ENT_QUOTES))) or die(print_r($gex -> errorInfo()));
		list($cc) = $gex -> fetch();
		$gex -> closeCursor();
		//die($cc);
		if($cc == 0){
			$reg = $connect_bdd -> prepare('INSERT INTO newsletter(addr, date_reg, unsub, sent, current, last_sent) VALUES(:add, :dr, :us, :se, :cur, :ls)');
			$reg -> execute(array('add' => htmlentities($_REQUEST['yourAddr'], ENT_QUOTES), 'dr'=>date('d/m/Y H:i:s'), 'us'=>'non', 'se'=>0, 'cur'=>'non', 'ls'=> 0)) or die(print_r($reg -> errorInfo()));;
			$reg -> closeCursor();
			$o = ['success' => true];
		}else{
			$o = ['success' => false, 'message'=>'Vous êtes déjà abonné aux nouvelles StreetZik'];
		}
	}else{
		$o = ['success'=>false, 'message' => "Votre adresse e-mail est incorrecte. != user@domain.tld"];
	}
}else{
	$o = ['success'=>false, 'message'=>'Vous n\'avez pas soumis d\'adresse e-mail'];
}

//if(isset($_SERVER['X_REQUESTED_WITH']) && strpos($_SERVER['X_REQUESTED_WITH'], strtolower('XMLHttpRequest')) != false)
	die(json_encode($o));

// if($o['success'])
// 	echo 'Vous etes bien inscrit a la newsletter!';
// else
// 	echo 'Erreur: '.$o['message'];