<?php
$out = array('end'=>'fail', 'message'=> 'Failed processing your request. Please try again later.');

//do what you want here
if(isset($_POST['artist'])){
    $art = $_POST['artist'];
    require_once '../config.php';
    $flist = array();
    $fnames = array();
    
    $q = $connect_bdd -> prepare('SELECT * FROM musics WHERE artiste=? AND moderation=0 ORDER BY id DESC');
    $q -> execute(array($art));
    $nb = $q -> rowCount();
    if(intval($nb)){
        while($res = $q -> fetch()){
            $flist[] = $res['nom_fichier'];
            //$ext = pathinfo($res['nom_fichier'], PATHINFO_EXTENSION);
            $fnames[] = urlencode_2(html_entity_decode($res['artiste']).'-'.html_entity_decode($res['titre']));
        }
        $out['end'] = 'succes';
        $out['message'] = 'all done';
        $out['filelist'] = implode(';', $flist);
        $out['filenames'] = implode('|||', $fnames);
        $out['nbFiles'] = intval($nb);
        $out['artist'] = urlencode_2(html_entity_decode($art));
    }else{
        $out['message'] = 'Aucun fichier dans cette liste.';
    }
    $q -> closeCursor();
}
echo json_encode($out);
