<?php 

$out = array('end'=>'fail', 'message'=>'Could not process your request now.');
require_once '../config.php';

if(isset($_POST['album'])){
    $alb = $_POST['album'];
    $files = array();
    $names = array();
    
    $q = $connect_bdd -> prepare('SELECT id_titres AS ids, annee FROM albums WHERE code_name=? AND moderation=0 LIMIT 1');
    $q -> execute(array( htmlentities($alb, ENT_QUOTES) ));
    $nb = $q -> rowCount();
    if(intval($nb)){
        $ff = $q -> fetch();
        $elts = explode(';', $ff['ids']);
    
        foreach($elts as $elt){
            $sh = $connect_bdd -> prepare('SELECT nom_fichier, artiste, titre FROM musics WHERE id=? AND moderation=0 LIMIT 1');
            $sh -> execute(array(intval($elt)));
            $c = intval($sh -> rowCount());
            if($c){
                $res = $sh -> fetch();
                $files[] = $res['nom_fichier'];
                $names[] = urlencode_2(html_entity_decode($res['artiste']).'-'.html_entity_decode($res['titre']));
                $art = $res['artiste'];
            }
            $sh -> closeCursor();
        }
        
        if(count($files)){
            $out['end'] = 'succes';
            $out['artist'] = urlencode_2(html_entity_decode($art));
            $out['message'] = 'all done';
            $out['filelist'] = implode(';', $files);
            $out['filenames'] = implode('|||', $names);
            $out['nbFiles'] = count($files);
            $out['album'] = $alb.'-album-complet';
            $out['albumCN'] = $alb;
        }
    }
    $q -> closeCursor();
}

echo json_encode($out);
