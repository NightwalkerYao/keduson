<?php
$out = array('message' => array(), 'success' => false);

$TaggingFormat = 'UTF-8';
require_once('../lib/getid3/getid3.php');
// Initialize getID3 engine
$getID3 = new getID3;
$getID3->setOption(array('encoding'=>$TaggingFormat));

getid3_lib::IncludeDependency(GETID3_INCLUDEPATH.'write.php', __FILE__, true);

//$browsescriptfilename = 'demo.browse.php';

$Filename = (isset($_REQUEST['Filename']) ? '../../files/'.$_REQUEST['Filename'] : '');
if (isset($_POST['WriteTags'])) {


	$TagFormatsToWrite = (isset($_POST['TagFormatsToWrite']) ? $_POST['TagFormatsToWrite'] : array());
	if (!empty($TagFormatsToWrite)) {
		//echo 'starting to write tag(s)<BR>';
		$tagwriter = new getid3_writetags;
		$tagwriter->filename       = $Filename;
		$tagwriter->tagformats     = $TagFormatsToWrite;
		$tagwriter->overwrite_tags = true;
		$tagwriter->tag_encoding   = $TaggingFormat;
		if (!empty($_POST['remove_other_tags'])) {
			$tagwriter->remove_other_tags = true;
		}

		// $commonkeysarray = array('titre', 'artiste', 'album', 'annee', 'Comment');
		// foreach ($commonkeysarray as $key) {
		// 	if (!empty($_POST[$key])) {
		// 		$TagData[strtolower($key)][] = $_POST[$key];
		// 	}
		// }
		$TagData['artist'][] = $_POST['artiste'].' - www.streetzik.net';
		$TagData['title'][] = $_POST['titre'].' - www.streetzik.net';
		$TagData['album'][] = $_POST['album'].' - www.streetzik.net';
		$TagData['year'][] = $_POST['annee'];
		$TagData['comment'][] = $_POST['Comment'];
		$TagData['publisher'][] = $_POST['label'] .' - www.streetzik.net';

		if (!empty($_POST['Genre'])) {
			$TagData['genre'][] = $_POST['Genre'];
		}
		if (!empty($_POST['genre'])) {
			$TagData['genre'][] = 'www.streetzik.net';//$_POST['genre'];
		}
		if (!empty($_POST['piste'])) {
			$TagData['track'][] = $_POST['piste'].(!empty($_POST['TracksTotal']) ? '/'.$_POST['TracksTotal'] : '');
		}

		if (!empty($_FILES['userfile']['tmp_name'])) {
			if (in_array('id3v2.4', $tagwriter->tagformats) || in_array('id3v2.3', $tagwriter->tagformats) || in_array('id3v2.2', $tagwriter->tagformats)) {
				if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
					if ($APICdata = file_get_contents($_FILES['userfile']['tmp_name'])) {

						if ($exif_imagetype = exif_imagetype($_FILES['userfile']['tmp_name'])) {

							$TagData['attached_picture'][0]['data']          = $APICdata;
							$TagData['attached_picture'][0]['picturetypeid'] = $_POST['APICpictureType'];
							$TagData['attached_picture'][0]['description']   = $_FILES['userfile']['name'];
							$TagData['attached_picture'][0]['mime']          = image_type_to_mime_type($exif_imagetype);

						} else {
							$out['message'][] = '<b>invalid image format (only GIF, JPEG, PNG)</b><br>';
						}
					} else {
						$out['message'][] = '<b>cannot open '.htmlentities($_FILES['userfile']['tmp_name']).'</b><br>';
					}
				} else {
					$out['message'][] = '<b>!is_uploaded_file('.htmlentities($_FILES['userfile']['tmp_name']).')</b><br>';
				}
			} else {
				$out['message'][] = '<b>WARNING:</b> Can only embed images for ID3v2<br>';
			}
		}
		//use file by name
		if(isset($_REQUEST['cover'])){
			$out['pictype']= 'Cover by name';
			if (in_array('id3v2.4', $tagwriter->tagformats) || in_array('id3v2.3', $tagwriter->tagformats) || in_array('id3v2.2', $tagwriter->tagformats)) {
				if (file_exists('../../covers/'.$_REQUEST['cover'])) {
					if ($APICdata = file_get_contents('../../covers/'.$_REQUEST['cover'])) {

						if ($exif_imagetype = exif_imagetype('../../covers/'.$_REQUEST['cover'])) {

							$TagData['attached_picture'][0]['data']          = $APICdata;
							$TagData['attached_picture'][0]['picturetypeid'] = $_POST['APICpictureType'];
							$TagData['attached_picture'][0]['description']   = 'Custom cover by The Nightwalker Y(www.streetzik.net)';
							$TagData['attached_picture'][0]['mime']          = image_type_to_mime_type($exif_imagetype);

						} else {
							$out['message'][] = '<b>invalid image format (only GIF, JPEG, PNG)</b><br>';
						}
					} else {
						$out['message'][] = '<b>cannot open ../../covers/'.$_REQUEST['cover'].'</b><br>';
					}
				} else {
					$out['message'][] = '<b>!file_exists(../../covers/'.$_REQUEST['cover'].')</b><br>';
				}
			} else {
				$out['message'][] = '<b>WARNING:</b> Can only embed images for ID3v2<br>';
			}
		}

		$tagwriter->tag_data = $TagData;
		if ($tagwriter->WriteTags()) {
			$out['success'] = true; // 'Successfully wrote tags<BR>';
			if (!empty($tagwriter->warnings)) {
				$out['message'][] =  'There were some warnings:<blockquote style="background-color: #FFCC33; padding: 10px;">'.implode('<br><br>', $tagwriter->warnings).'</div>';
			}
		} else {
			$out['message'][] = 'Failed to write tags!<div style="background-color: #FF9999; padding: 10px;">'.implode('<br><br>', $tagwriter->errors).'</div>';
		}

	} else {

		$out['message'][] ='WARNING: no tag formats selected for writing - nothing written';

	}
	//echo '<HR>';

}
echo json_encode($out);