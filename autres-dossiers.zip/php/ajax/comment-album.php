<?php 
$out = array('end'=> 'fail', 'message'=>'');
require_once '../config.php';

if(isset($_POST['group'], $_POST['row'], $_POST['texte']) && strlen(trim($_SESSION['uname'])) > 2 && strlen(trim($_POST['text'])) > 1 ){
    $ins = $connect_bdd -> prepare('INSERT INTO album_comments(album_cn,auteur,texte,date_post) VALUES(?,?,?,?)');
    $ins -> execute(array(htmlentities($_POST['albumId'], ENT_QUOTES), htmlentities($_POST['username'], ENT_QUOTES), $_POST['text'], time()));
    $n = $connect_bdd -> lastInsertId();
    if($n){
        $out['end'] = 'succes';
        $out['message'] = '';
        $out['text'] = htmlspecialchars($_POST['text']);
        $out['username'] = urlencode(htmlentities($_POST['username'], ENT_QUOTES));
        
        $up_comm = $connect_bdd -> prepare('UPDATE albums SET commentaires=commentaires+1 WHERE code_name=?');
			$up_comm -> execute(array(htmlentities($_POST['albumId'], ENT_QUOTES)));
			$up_comm->closeCursor();
    }else{
        $out['message'] = 'Ajout du commentaire echoue #0';
    }
}else{
    $out['message'] = 'Missed some parameters in request headers. Be sure all fields are filled.';
}
echo json_encode($out);
