<?php 
$out = array('end'=> 'fail', 'message'=>'');
require_once '../config.php';

if(isset($_POST['group'], $_POST['row'], $_POST['texte']) && (strlen(trim($_SESSION['uname'])) > 2) && (strlen(trim($_POST['texte'])) > 4) && (in_array($_POST['group'], ['music', 'album'])) ){
    $col1 = ($_POST['group'] == 'music') ? 'titre_cn' : 'album_cn';
    $stmt = 'INSERT INTO '.$_POST['group'].'_comments('.$col1.',auteur,texte,date_post) VALUES(?,?,?,?)';
    $ins = $connect_bdd -> prepare($stmt);
    $ins -> execute(array(het($_POST['row']), het($_SESSION['uname']), $_POST['texte'], time()));
    $n = $connect_bdd -> lastInsertId();
    if($n){
        $out['end'] = 'succes';
        $out['message'] = '';
        $out['texte'] = nl2br(htmlspecialchars($_POST['texte']));
        $out['uname'] = htmlspecialchars($_SESSION['uname']);
        $out['date_post'] = date('d/m/Y \à H:i');
        
        $sql = 'UPDATE '.$_POST['group'].'s SET commentaires=commentaires+1 WHERE code_name=?';
        $up_comm = $connect_bdd -> prepare($sql);
			$up_comm -> execute(array(het($_POST['row'])));
			$up_comm->closeCursor();
    }else{
        $out['message'] = 'Ajout du commentaire echoue #0';
    }
}else{
    $out['message'] = 'Veillez bien remplir tous les champs. Votre commentaire ne doit pas être trop court.';
}
echo json_encode($out);
