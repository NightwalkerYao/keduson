<?php
$out = array();
if(isset($_REQUEST['targetfile'], $_REQUEST['file_type'])){
	require_once '../lib/getid3/getid3.php';
    $dir = "";
    $dir .= ($_REQUEST['file_type'] == 'temp' ? '../../temp_upz/' : '../../files/');
    
    $file = $dir.strip_tags($_REQUEST['targetfile']);
    if(file_exists($file)){
        $yy = new getID3;
        $arr = $yy -> analyze($file);
        getid3_lib::CopyTagsToComments($arr);

        if(isset($arr['comments'])){
            $tag = $arr['comments'];
            $bitrate = $arr['audio']['bitrate']/1024;
            $bitrate .='kbps';
            $duree = $arr['playtime_string'];
            $out["end"] = "success";
            $out["artist"] = @$tag['artist'][0];
            $out["title"] = @$tag['title'][0];
            $out["album"] = @$tag['album'][0];
            $out["year"] = @$tag['year'][0];
            $out["track"] = @$tag['track'][0];
            $out["genre"] = @$tag['genre'][0];
            $out["label"] = @$tag['publisher'][0];
            $out["bitrate"] = @$bitrate;
            $out["duration"] = @$duree;
        }else{
            $out["end"] = "fail";
            $out["message"] = "Le fichier ne possède pas de tags ID3.";
        }
    }else{
		$out["end"] = "fail";
		$out["message"] = "Le fichier n'existe pas.";
    }
}else{
    $out["end"] = "fail";
    $out["message"] = "Aucun ou paramètres manquants dans l'URI.";
}

if(isset($_REQUEST['reqid']))
    $out['reqid'] = intval($_REQUEST['reqid']);
if(isset($_REQUEST['div']))
    $out['div'] = $_REQUEST['div'];
    
echo json_encode($out);
?>
