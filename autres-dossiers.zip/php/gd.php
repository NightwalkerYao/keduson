<?php
	function Redim($source_path,$width,$height,$wd){
	$cp = explode('.', $source_path);
	$type_ext = $cp[count($cp)-1];
	$type_ext = strtolower($type_ext);
	$width = intval($width); $height = intval($height);
	
	if($type_ext == 'jpg' OR $type_ext == 'jpeg'){
		//redimension
		$origine = imagecreatefromjpeg($wd.$source_path);
		$direction = imagecreatetruecolor($width,$height);
		$original_width = imagesx($origine);
		$original_height = imagesy($origine);
		$copy_width = imagesx($direction);
		$copy_height = imagesy($direction);
		imagecopyresampled($direction,$origine,0,0,0,0,$copy_width,$copy_height,$original_width,$original_height);
		imagejpeg($direction, $wd.str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.jpg');
		return str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.jpg';
	}elseif($type_ext == 'png'){
		$origine = imagecreatefrompng($wd.$source_path);
		$direction = imagecreatetruecolor($width,$height);
		$original_width = imagesx($origine);
		$original_height = imagesy($origine);
		$copy_width = imagesx($direction);
		$copy_height = imagesy($direction);
		imagecopyresampled($direction,$origine,0,0,0,0,$copy_width,$copy_height,$original_width,$original_height);
		imagepng($direction, $wd.str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.png');
		return str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.png';
	}elseif($type_ext = 'gif'){
		$origine = imagecreatefromgif($wd.$source_path);
		$direction = imagecreatetruecolor($width,$height);
		$original_width = imagesx($origine);
		$original_height = imagesy($origine);
		$copy_width = imagesx($direction);
		$copy_height = imagesy($direction);
		imagecopyresampled($direction,$origine,0,0,0,0,$copy_width,$copy_height,$original_width,$original_height);
		imagegif($direction,$wd.str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.gif');
		return str_replace('.'.$type_ext, '', $source_path).'-'.$width.'X'.$height.'.gif';
	}
}


function Tag($filigranne,$img_cible,$wd){
    $cp = explode('.', $img_cible);
	$type_ext = $cp[count($cp)-1];
	$type_ext = strtolower($type_ext);
	$sourcefil = imagecreatefrompng($filigranne);
	$fili_w = imagesx($sourcefil); $fili_h = imagesy($sourcefil);
	if($type_ext == 'jpg' OR $type_ext == 'jpeg'){
		$cible = imagecreatefromjpeg($wd.$img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,70);
		imagejpeg($cible,$wd.str_replace('.'.$type_ext, '', $img_cible).'.'.$type_ext);
	}else if($type_ext == 'png'){
		$cible = imagecreatefrompng($wd.$img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,70);
		imagepng($cible, $wd.str_replace('.'.$type_ext, '', $img_cible).'.'.$type_ext);
	}else if($type_ext == 'gif'){
		$cible = imagecreatefromgif($wd.$img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,20);
		imagegif($cible,$wd.str_replace('.'.$type_ext, '', $img_cible).'.'.$type_ext);
	}
	return str_replace('.'.$type_ext, '', $img_cible).'.'.$type_ext;
}

function Resolution($path){
    $wh = array();
    $g = getimagesize($path);
    $wh["width"] = $g[0];
    $wh["height"] = $g[1];
    return $wh;
}
/*
function GDTag2($type_ext,$filigranne,$img_cible,$nom_final){
	//header('Content-type: image/'.$type_ext);
	$type_ext = strtolower($type_ext);
	$sourcefil = imagecreatefromgif($filigranne);
	$fili_w = imagesx($sourcefil); $fili_h = imagesy($sourcefil);
	if($type_ext == 'jpg' OR $type_ext == 'jpeg'){
		$cible = imagecreatefromjpeg($img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,70);
		imagejpeg($cible,$img_cible);
	}else if($type_ext == 'png'){
		$cible = imagecreatefrompng($img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,70);
		imagepng($cible,$img_cible);
	}else if($type_ext == 'gif'){
		$cible = imagecreatefromgif($img_cible);
		$cible_w = imagesx($cible); $cible_h = imagesy($cible);
		$dest_w = $cible_w - $fili_w;
		$dest_h = $cible_h - $fili_h;
		imagecopymerge($cible,$sourcefil,$dest_w,$dest_h,0,0,$cible_w,$cible_h,20);
		imagegif($cible,$img_cible);
	}
	return rootpath.'uploader/images/'.$nom_final;
}*/
?>
