<?php
if(!$c){
    include_once('error.php');
}else{
    echo '<table class="artistable"> <thead> <tr class="sombre"> <th> Artistes </th> <th> Contenu </th> </tr> </thead>';
    echo '<tbody>';
    $defclass = 'sombre';
    
    while($res = $areq -> fetch()){
        $defclass = (($defclass == 'sombre') ? 'clair' : 'sombre');
        
        $getinfos = $connect_bdd -> prepare('SELECT COUNT(titre) AS nbtitre, SUM(hits) AS thits, SUM(likes) AS tlikes FROM musics WHERE artiste=? AND moderation=0' );
        $getinfos -> execute(array($res['artiste']));
        $gti = $getinfos -> fetch();
        $getinfos -> closeCursor();
        
        $getalbs = $connect_bdd -> prepare('SELECT nom, annee, code_name, pochette FROM albums WHERE artiste = ? AND moderation=0');
        $getalbs -> execute(array($res['artiste']));
        $calb = intval($getalbs -> rowCount());
        ?>
        <tr class="<?=$defclass;?>">
            <td>
                <big>
                    <a href="<?=ROOT_SANS.'/artist/'.urlencode(html_entity_decode($res['artiste']));?>"> <?=$res['artiste'];?> </a>
                </big>
            </td>
            <td>
                <?=$gti['nbtitre'];?> Titre<?=(($gti['nbtitre']>1) ? 's' : false);?> | <?=$gti['thits'];?> Download<?=(($gti['thits']>1) ? 's' : false);?> | <?=$gti['tlikes'];?> Like<?=(($gti['tlikes']>1) ? 's' : false);?> 
                <br>
                <?php 
                if($calb){
                    $dsplayed = 1;
                    while(($falb = $getalbs -> fetch()) && $dsplayed<4){
                        ?>
                            <a href="<?=ROOT_SANS.'/album/'.$falb['code_name'];?>"> <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '65X65', $falb['pochette']);?>" alt="<?=$res['artiste'].' '.$falb['nom'];?>" width="36" style="position:relative; top:10px;" /> <?=$falb['nom'];?> </a> <span>(<?=$falb['annee'];?>)</span>
                        <?php
                        if($dsplayed<3 && $dsplayed<$calb)
                            echo ' , ';
                        $dsplayed++;
                    }
                }else
                    echo '<small> <i> aucun album disponible. </i> </small>';
                $getalbs -> closeCursor();
                ?>
            </td>
        </tr>
        <?php
    }
    $areq -> closeCursor();
?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2"> 
                    <?php
                    echo $nbpg.' page'.(($nbpg>1) ? 's' : false).' | &nbsp;';
                        for($i=$apg-7; $i<=$apg+7; $i++){
                            if($i>0 && $i<=$nbpg){
                                if($i != $apg)
                                    echo '<a href="'.ROOT_SANS.'/artists/page-'.$i.'"> '.$i.' </a>';
                                else
                                    echo '<span> '.$i.' </span>';
                            }
                        }
                    ?>
                </td>
            <tr>
        </tfoot>
    </table>
<?php } ?>
