<?php 
require_once '../config.php';
if(isset($_GET['artist'], $_SERVER['HTTP_REFERER'])){
    $art = strip_tags(urldecode($_GET['artist']));
    $flist = array();
    $fnames = array();
    
    $q = $connect_bdd -> prepare('SELECT * FROM musics WHERE artiste=? AND moderation=0 ORDER BY id DESC');
    $q -> execute(array($art));
    $nb = $q -> rowCount();
    if(intval($nb)){
        while($res = $q -> fetch()){
            $flist[] = $res['nom_fichier'];
            //$ext = pathinfo($res['nom_fichier'], PATHINFO_EXTENSION);
            $fnames[] = urlencode_2(html_entity_decode($res['artiste']).'-'.html_entity_decode($res['titre']));
        }
    }else{
        die('Aucun fichier dans cette liste.');
    }
    $q -> closeCursor();
    
    //ziping
    $nbFiles = intval($nb);
    $dlname = $art.'-'.$nbFiles.'-titres.zip';
    
    //dir to store all zips
    if(!is_dir('../../zipped'))
        mkdir('../../zipped', 0777);
    
    //deleted log dir
    if(!is_dir('../../deleted_log'))
        mkdir('../../deleted_log', 0777);
        
    //delete old archives
    $existing_archs = scandir('../../zipped/');
    foreach($existing_archs as $ea){
        if($ea != '.' && $ea != '..' && $ea != 'index.php' && $ea != 'home.php' && $ea != '.htaccess' && $ea != 'index.html'){
            if(intval(filemtime('../../zipped/'.$ea)) < (time()-60*60*4)){
                if(@unlink('../../zipped/'.$ea)){
                    $dlfile = '../../deleted_log/artist_zips.txt';
                    if(file_exists($dlfile) && filesize($dlfile)>=500000){
                        rename($dlfile, '../../deleted_log/artist_zips-'.date('YmdHis').'.log');
                    }
                    $dlop = fopen($dlfile, 'a+');
                    fwrite($dlop, date('d/m/Y H:i:s').' '.$ea.' deleted \r\n ');
                    fclose($dlop);
                }
            }
        }
    }
    
//the function

function create_zip($files = array(),$destination = '',$overwrite = false) {
	//if the zip file already exists and overwrite is false, return false
	if(file_exists($destination) && !$overwrite) { return false; }
	//vars
	$valid_files = array();
	//if files were passed in...
	if(is_array($files)) {
		//cycle through each file
		foreach($files as $file) {
			//make sure the file exists
			if(file_exists($file)) {
				$valid_files[] = $file;
			}
		}
	}
	//if we have good files...
	if(count($valid_files)) {
		//create the archive
		$zip = new ZipArchive();
		if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
			return false;
		}
		//add the files
		foreach($valid_files as $file) {
			$zip->addFile($file,$file);
		}
		//debug
		//echo 'The zip archive contains ',$zip->numFiles,' files with a status of ',$zip->status;
		
		//close the zip -- done!
		$zip->close();
		
		//check to make sure the file exists
		return file_exists($destination);
	}
	else
	{
		return false;
	}
}
//end of function

    $filz = $flist;
    $namz = $fnames;
    
    //if the same file already exists and not expired (old of 4h)
    if(file_exists('../../zipped/'.$dlname)){
        foreach($filz as $f){
            $hit = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE nom_fichier=? LIMIT 1');
            $hit -> execute(array(htmlentities($f, ENT_QUOTES)));
            $hit -> closeCursor();
        }

    }else{ //create the archive file
        if(!is_dir('./'.urlencode_2($_GET['artist'])))
            mkdir('./'.urlencode_2($_GET['artist']), 0777);
            
        $true_files = array();
        
        for($i=0; $i<count($filz); $i++){
            $filz[$i] = str_replace('../','',$filz[$i]); //do no go to top dir. sec
                if(file_exists('../../files/'.$filz[$i])){
                    $ext = '.'.pathinfo($filz[$i], PATHINFO_EXTENSION);
                    @copy('../../files/'.$filz[$i], './'.urlencode_2($_GET['artist']).'/'.$namz[$i].$ext);
                    $true_files[] = urlencode_2($_GET['artist']).'/'.$namz[$i].$ext;
                }
            //}
            
            //set hit+1 (downloaded)
            $hit = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE nom_fichier=? LIMIT 1');
            $hit -> execute(array(htmlentities($filz[$i], ENT_QUOTES)));
            $hit -> closeCursor();
        }
        
        if(count($true_files) && create_zip($true_files, '../../zipped/'.$dlname, false)){
            //clean trashes
            foreach($true_files as $tf){
                @unlink($tf);
            }
            @rmdir('./'.urlencode_2($_GET['artist']));
            
        }else{
            die("La création de l'archive a échoué. Veillez essayer à nouveau.");
        }
    }
    
    //dlding---
    $f = $dlname;
    if(file_exists('../../zipped/'.$f) && strpos(strtolower($_SERVER['HTTP_REFERER']), '/about/') !== false){
        $path = '../../zipped/'.$f;
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$f.'"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, GET-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: '.filesize($path));
        readfile($path);
        exit;
    }else{
        die("Vous n'êtes pas autorisés à télécharger ce fichier. / You are not allowed to download this file. #1");
    }
}else{
    header('Location:'.ROOT_SANS);
    exit;
}

