<script>
var intervalle = setInterval(function(){
    var auj = new Date(), dd, mm, yy, hh,ii,ss,str, hello;
    //console.log(auj);
    dd = (auj.getDate()<10 ? '0'+auj.getDate() : auj.getDate());
    mm = auj.getMonth()+1;
    mm = (mm<10 ? '0'+mm : mm);
    yy = auj.getFullYear();
    hh = auj.getHours();
    if(hh>=0 && hh<4)
        hello = 'Bonne nuit, faites de beaux rêves !';
    else if(hh>=4 && hh<12)
        hello = 'Bonjour, passez une agréable journée !';
    else if(hh>=12 && hh<17)
        hello = 'Bonne après midi !';
    else if(hh>=17 && hh<19)
        hello = 'Bonsoir !';
    else if(hh>=19 && hh<22)
        hello = 'Bonne soirée !';
    else if(hh>=22 && hh<24)
        hello = 'Excellente nuit !';

    hh = (hh<10 ? '0'+hh : hh);
    ii = auj.getMinutes();
    ii = (ii<10 ? '0'+ii : ii);
    ss = auj.getSeconds();
    ss = (ss<10 ? '0'+ss : ss);
    str = dd+'/'+mm+'/'+yy+' '+hh+':'+ii+':'+ss+' - '+hello;
    document.getElementById('dynHorloge').innerHTML = str;
}, 1000);
</script>
<div class="contain-dbl"> 
<h1 class="home-sec-ttle"> <img width="36" src="<?=ROOT_SANS;?>/img/icones/icons8-Notification.png" alt="icone Notification"> Nouvelles </h1>
<?php 
$nws = $connect_bdd -> prepare('SELECT * FROM nouvelles ORDER BY id DESC LIMIT 2');
$nws -> execute();
while($nvl = $nws -> fetch()){
    ?>
    <div class="nvlle">
        <h2> <img width="30" src="<?=ROOT_SANS;?>/img/icones/icons8-List.png" alt="Liste"> &nbsp; <?=$nvl['sujet'];?> </h2>
        <div align="justify"> <?=$nvl['texte'];?> </div>
        <span> le <?=date('d\-m\-Y\ \à H\hi', $nvl['date_post']);?> par <strong><?=$nvl['auteur'];?></strong> </span>
    </div>
    <?php
}
$nws -> closeCursor();
?>
<br>
</div>

<div class="contain-dbl no-mobile"> 
<h1 class="home-sec-ttle"> <img width="36" src="<?=ROOT_SANS;?>/img/icones/icons8-Musical.png" alt="icone Notification"> Exclusifs </h1>
<?php 
//$thisY = date('Y');
$xclu = $connect_bdd -> prepare('SELECT * FROM musics WHERE moderation=0 ORDER BY id DESC LIMIT 15');
$xclu -> execute();
$a = 1;
while($xc = $xclu -> fetch()){
    ?>
    <table class="xclusiv">
        <tr>
        <td align="right" class="xclucov">
        <img width="85" src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '100X100', $xc['pochette']);?>" alt="Cover">
        </td>
        <td align="left" > 
            <span style="color:#CCC; font-weight:bold;"> <?=$xc['titre'];?></span><br>
            <span style="color:orange;"> <?=$xc['artiste'];?> </span><br>
            <i><?=$xc['hits'];?> hits</i><br>
            <small>Added: <?=date('d.m H\hi',$xc['date_upload']).' by '.strip_tags($xc['uploader']);?> </small>
            <br>
            <a href="<?=ROOT_SANS.'/about/'.$xc['code_name'];?>">DETAILS</a>
        </td>
        </tr>
    </table>
    <?php
    if(($a%3) == 0 && $a != 15)
        echo '<div style="height: 0px; border-bottom: 0.5px solid rgba(10,20,30,0.8);"></div>';
    $a++;
}
$xclu -> closeCursor();
?>
<br>
</div>

<div class="contain-dbl">
<h1 class="home-sec-ttle"> <img width="36" src="<?=ROOT_SANS;?>/img/icones/icons8-Help.png" alt="icone Aide"> Tutoriels pour bien commencer</h1>

<h2> Comment télécharger (download)? </h2>
<div align="justify" style="padding: 0 0.4em;"> 
    Pour télécharger, rendez-vous sur la page de détails du morceau ou de l'album concerné. Dans la section "Actions", choisissez le bouton "Télécharger" ou "Obtenir" et patientez le temps que nous préparons votre fichier. Une fois prêt, un lien vous est fourni, Cliquez dessus pour passer directement au téléchargement. <br>
    Si vous rencontrez encore des difficultés, venez nous voir dans "LE CLUB".
</div>
<h2> Comment téléverser (upload)? </h2>
<div align="justify" style="padding: 0 0.4em;"> 
    Voyez le guide sur cette page: <a href="<?=ROOT_SANS;?>/p/add#needHelp">Page d'upload</a>
</div>
<br>
</div>
<section id="disclaimer" class="contain-dbl"> 
<h1 class="home-sec-ttle"> <!-- <img width="36" src="<?=ROOT_SANS;?>/img/icones/icons8-Info.png" alt="icone info">--> &#9888; Disclaimer &#9888;</h1>
<div class="disclaimer" align="right">
    <?php 
    $dis = $connect_bdd -> prepare('SELECT texte,date_maj FROM disclaimer ORDER BY id DESC LIMIT 1');
    $dis -> execute();
    $di = $dis -> fetch();
    $dis -> closeCursor();
    
    echo $di['texte'];
    echo '<br>';
    echo 'last update: '.date('m.d.Y, H:i', $di['date_maj']);
    ?> 
</div>
</section>
