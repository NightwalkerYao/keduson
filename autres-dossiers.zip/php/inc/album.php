<?php if(!$c){
    include_once('error.php');
}else{
?>
<div class="albcorps contain-dbl">
                            <div id="albcover">
                                <img src="<?=ROOT_SANS;?>/covers/<?=$res['pochette'];?>" alt="Album cover">
                            </div>
                            <div id="albinfos">
                                <h3 class="home-sec-ttle"><?=$res['artiste'].' - '.$res['nom'];?></h3>
                                <small> <?=$res['label'];?> </small> 
                                <br>
                                <span id="albauthor"><img src="<?=ROOT_SANS;?>/img/icones/icons8-DJ.png" alt="" class="icon incontent"> <a href="<?=ROOT_SANS.'/artist/'.urlencode(html_entity_decode($res['artiste']));?>"> <?=$res['artiste'];?> </a> </span>
                                <br>
                                <span id="albyear"><img src="<?=ROOT_SANS;?>/img/icones/7-48.png" alt="" class="icon incontent"> <?=$res['annee'];?> </span>
                                <br>
                                <span id="albgenre"> &nbsp; &nbsp; <img src="<?=ROOT_SANS;?>/img/icones/icons8-Rock Music.png" alt="" class="icon incontent"> <?=$res['genre'];?> </span>
                                <br>
                                <span id="albnbtitles"><img src="<?=ROOT_SANS;?>/img/icones/icons8-CD Collection.png" alt="" class="icon incontent"> <?=count(explode(';', $res['id_titres']));?> titres</span>
                                <br>
                                <span id="albdls"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Download.png" alt="" class="icon incontent"> <?=$res['hits'];?> Téléchargements</span>
                                <br>
                                <span id="alblikes"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Facebook Like.png" alt="" class="icon incontent"> <?=$res['likes'];?> likes</span>
                                <span id="albdislikes"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Thumbs Down.png" alt="" class="icon incontent"> <?=$res['dislikes'];?> dislikes</span>
                                <br>
                                <span id="albcomm"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Comments.png" alt="" class="icon incontent"> <?=$res['commentaires'];?> commentaires</span>
                                <br>
                                <span id="albuploader"><img src="<?=ROOT_SANS;?>/img/icones/icons8-technical support.png" alt="" class="icon incontent"> <small>par </small> <a href="<?=ROOT_SANS.'/user/'.urlencode($res['uploader']);?>"> <?=$res['uploader'];?> </a> </span>
                                </div>
                        </div>
                        <br>
                        <br>

                        <div id="tileBuy">
                            <div>
                                <div id="external_buy_links">
                                <span>Acheter</span> &nbsp; &nbsp; &nbsp;
                                    <a title="Acheter sur Itunes" target="_blank" href="https://google.com/search?q=site:itunes.apple.com+<?=urlencode($res['artiste'].' '.$res['nom']);?>"> <img src="<?=ROOT_SANS;?>/img/itunes.png" alt="Itunes"></a>
                                    <a title="Acheter sur Amazon" target="_blank" href="https://music.amazon.com/search/<?=urlencode($res['artiste'].' '.$res['nom']);?>"> <img src="<?=ROOT_SANS;?>/img/amazon.jpg"></a>
                                    <a title="Acheter sur Google Play Music" target="_blank" href="https://play.google.com/store/search?q=<?=urlencode($res['artiste'].' '.$res['nom']);?>&c=music"> <img src="<?=ROOT_SANS;?>/img/play-music.png"></a>
                                    <a title="Acheter sur Qobuz" target="_blank" href="https://www.qobuz.com/fr-fr/search?q=<?=urlencode($res['artiste'].' '.$res['nom']);?>&i=boutique"><img src="<?=ROOT_SANS;?>/img/qobuz.jpg"></a>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div id="albtoolbar">
                            <span class="albliketitle"> Actions </span> 
                            
                            <button type="button" id="albumplay" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Play Album.png" alt="" class="icon incontent"> Jouer</button>
                            
                            <button type="button" id="albumaddlike" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Heart.png" alt="" class="icon incontent"> Top(<span id="nbtlikes"><?=$res['likes'];?></span>)</button>
                            
                            <button type="button" id="albumadddislike" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Thumbs Down.png" alt="" class="icon incontent"> Flop(<span id="nbtulikes"><?=$res['dislikes'];?></span>)</button>
                            
                            <button type="button" id="albumdl" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Downloads.png" alt="" class="icon incontent"> Obtenir</button>
                            <!--hidden by default-->
                            <div id="dlAllProcessDialog" title="Télécharger <?=$res['artiste'].' - '.$res['nom'];?> - album complet" style="display:none; text-align:center;">
                            <h2 id="massDlStatus">Préparation du téléchargement..</h2>
                            <br>
                            <img src="<?=ROOT_SANS;?>/img/Load.gif" alt="" width="100" id="dialoader"> 
                            <br>
                            <span id="massDlStext">Récupération de la liste des fichiers.</span>
                            </div>
                            <!--hidden dialog box : end-->
                            <button type="button" id="ttleshare" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Share.png" alt="" class="icon incontent"> Partager</button>
                            <!--share dialog start-->
                            <div id="shareDialog" style="display:none; text-align:center;" title="Partager <?=$res['artiste'].' - '.$res['nom'];?>">
                                <h2>Partager <?=$res['artiste'].' - '.$res['nom'];?> <br>avec</h2>
                                <br>
                                <a href="//twitter.com/intent/tweet?text=<?=urlencode("Télécharger et écouter ".html_entity_decode($res['artiste'].' - '.$res['nom']));?>&url=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']); ?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Twitter.png" alt=""> </a>
                                <a href="//facebook.com/sharer.php?u=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']);?>&t=<?=urlencode('Télécharger et écouter '.html_entity_decode($res['artiste'].' - '.$res['nom']));?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Facebook.png" alt=""> </a>
                                <a href="//plus.google.com/share?url=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']); ?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Google Plus.png" alt=""> </a>
                            </div>
                            <!--share album dialog end -->
                            <button type="button" id="albaddcomment" class="button-actionbar" data-albumCN="<?=$res['code_name'];?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Comments_2.png" alt="" class="icon incontent"> Commenter</button>
                            
                        </div>

                        <div id="keyword_s" align="left" class="contain-dbl">
                            <h1 class="home-sec-ttle">Tags</h1>
                            <p style="padding:0.3em;">
                                <?php
                                    echo "Ecouter $res[artiste] $res[nom] , $res[genre], Telecharger $res[artiste] $res[nom] mp3 gratuit, Download $res[artiste] $res[nom] free, $res[artiste] $res[nom] album complet, $res[annee], Nouveautés ".date('Y')." de $res[artiste], mp3 gratuit, aac, m4a, flac, zip, torrent , Streetzik.net , music, streaming $res[artiste], les sons de $res[label], upload par $res[uploader], direct downolad music, Musicbox.cf Team $res[artiste] $res[nom].mp3 , Index of $res[artiste] mp3 Tous les telechargements de musique sur www.Streetzik.net";
                                ?>
                            </p>
                        </div>

                        <div id="albtracklist">
                            <h2><img src="<?=ROOT_SANS; ?>/img/icones/icons8-Smart Playlist.png" alt="" class="icon intitle">Tracklist</h2>
                            <ul id="albtrackz">
                            
                            <?php
                            $tids = explode(';', $res['id_titres']);
                            $nbtit = 0;
                            foreach($tids as $tid){
                                $gid = $connect_bdd -> prepare('SELECT * FROM musics WHERE id=? AND moderation=0 LIMIT 1');
                                $gid -> execute(array(intval($tid)));
                                
                                $cnt = intval($gid -> rowCount());
                                $t = $gid -> fetch();
                                $gid -> closeCursor();
                                if($cnt){
                                    $nbtit++;
                                    ?>
                                    <li><img src="<?=ROOT_SANS;?>/img/icones/icons8-Circled Play.png" alt="" class="icon inlist"> <a href="<?=ROOT_SANS;?>/about/<?=$t['code_name'];?>" class="tracklink"><?=$t['titre'];?></a> 
                                    <br>
                                    <span class="trackduration"><?=$t['duree'];?></span> &nbsp;
                                    <span class="trackdls"><?=$t['hits'];?></span> &nbsp;
                                    <span class="tracklk"><?=$t['likes'];?></span> &nbsp;
                                    <span class="trackdlk"><?=$t['dislikes'];?></span> &nbsp;
                                    <span class="trackcomm"><?=$t['commentaires'];?></span>
                                    </li>
                                    <?php
                                }
                            }
                            if(!$nbtit){
                                echo 'La Tracklist n\'est pas disponible pour le moment.';
                            }
                            ?>
                            </ul>
                        </div>
                        
                        <div id="artmore">
                            <h2><img src="<?=ROOT_SANS; ?>/img/icones/icons8-DJ.png" alt="" class="icon intitle"><?=$res['artiste'];?></h2>
                            <span id="arttrackz">
                            <?php 
                                $counttt = $connect_bdd -> prepare('SELECT COUNT(*) AS ct FROM musics WHERE artiste=? AND moderation=0');
                                $counttt -> execute(array($res['artiste']));
                                list($ctt) = $counttt -> fetch();
                                $counttt -> closeCursor();
                            ?>
                               <span> <?=$ctt;?> Morceau<?=((intval($ctt)>1)?'x':false);?> </span>
                               <br>
                                <a href="<?=ROOT_SANS.'/artist/'.urlencode(html_entity_decode($res['artiste']));?>"> <button type="button" class="button-actionbar"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Music Album.png" alt="" class="incontent icon"> Tout voir</button> </a>
                                
                                <button type="button" class="button-actionbar"><img src="<?=ROOT_SANS;?>/img/icones/icons8-Create Archive.png" alt="" class="incontent icon"> Tout télécharger</button>
                            </span>
                        </div>
                        
                        <div id="seemore" class="contain-dbl">
                            <h1 class="home-sec-ttle" style="text-align: left; "><img src="<?=ROOT_SANS; ?>/img/icones/icons8-Add Album.png" alt="" width="36"> D'autres albums</h1>
                            <ul>
                            <?php
                                $csug = 0;
                                $getsug = $connect_bdd -> prepare('SELECT * FROM albums WHERE code_name!=? AND genre LIKE ? AND moderation=0 ORDER BY id DESC LIMIT 5');
                                $getsug -> execute(array($res['code_name'], '%'.$res['genre'].'%'));

                                $lim = intval($getsug -> rowCount()); //fetched elements
                                while ($dd = $getsug -> fetch()) {
                                    $csug++;
                                    ?>
                                    <li style="text-align: center;">
                                        <a href="<?=ROOT_SANS.'/album/'.$dd['code_name'];?>">
                                            <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $dd['pochette']);?>" alt="<?=$dd['artiste'].' - '.$dd['nom'];?>" width="125">
                                            <br>
                                            <?=$dd['artiste'].' - '.$dd['nom'];?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                $getsug -> closeCursor();

                                if($lim < 5){ //less than 5 elements got. another query to complete to 5 rows total.
                                $rest = 5-$lim;
                                $sql = 'SELECT * FROM albums WHERE code_name!=? AND genre NOT LIKE ? AND moderation=0 ORDER BY id DESC LIMIT '.$rest;
                                $getsug2 = $connect_bdd -> prepare($rest);
                                $getsug2 -> execute(array($res['code_name'], '%'.$res['genre'].'%'));

                                while ($dd2 = $getsug2 -> fetch()) {
                                    $csug++;
                                    ?>
                                    <li style="text-align: center;">
                                        <a href="<?=ROOT_SANS.'/album/'.$dd2['code_name'];?>">
                                            <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $dd2['pochette']);?>" alt="<?=$dd2['artiste'].' - '.$dd2['nom'];?>" width="90%">
                                            <br>
                                            <?=$dd2['artiste'].' - '.$dd2['nom'];?>
                                        </a>
                                    </li>
                                    <?php
                                }
                                $getsug2 -> closeCursor();
                                }
                                
                                if(!$csug)
                                    echo 'Aucune suggestion disponible.';
                            ?>
                            </ul>
                        </div>
                        
                        <div id="docomments" class="contain-dbl">
                        <?php
                            $comms = $connect_bdd -> prepare('SELECT * FROM album_comments WHERE album_cn=?');
                            $comms -> execute(array(htmlentities($res['code_name'], ENT_QUOTES)));
                            $nb_coms = $comms -> rowCount();
                        ?> 
                            <h1 class="home-sec-ttle"><img src="<?=ROOT_SANS; ?>/img/icones/icons8-Comments_50.png" alt=""> Commentaires</h1>
                            
                            <form id="albumaddComment" method="post">
                                <div style="padding-left: 5px; ">
                                    <label for="username" class="libelef">Identifiant: </label>
                                    <br>
                                    <input type="text" name="username" id="username" class="midlleinput" value="<?=$_SESSION['uname'];?>" readonly>
                                    <br>
                                    <label for="comment" class="libelef">Message: </label>
                                    <br>
                                    <textarea id="comment" rows="4" name="text"></textarea>
                                    <br>
                                    <br>
                                    <input type="hidden" name="albumId" value="<?=$res['code_name'];?>" id="albumId">
                                    &nbsp; &nbsp; &nbsp; <input type="submit" value="Soumettre" id="subcomment" class="button-normal">
                                </div>
                            </form>
                            
                            <table>
                                <?php
                                    $pp=1;
                                    while($cm = $comms -> fetch()){
                                        ?>
                                    <tr id="comment_<?=$cm['id'];?>"> 
                                        <td> 
                                            <img src="<?=ROOT_SANS;?>/img/icones/icons8-Boombox.png" alt="" width="55"> 
                                            <!-- <br> -->
                                            <a href="<?=ROOT_SANS.'/user/'.urlencode($cm['auteur']);?>"><?=$cm['auteur'];?></a>
                                        </td> 
                                        <td> <?=nl2br(htmlspecialchars($cm['texte']));?>
                                            <br>
                                            <small><i>Commentaire N°<?=$pp;?> - le <?=date('d/m/Y \à H:i', $cm['date_post']);?> </i></small>
                                        </td> 
                                    </tr> 
                                    <?php
                                    $pp++;
                                    }
                                    $comms -> closeCursor();
                                ?>
                            </table>
                        </div>
<?php }
?>
