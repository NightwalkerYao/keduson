<section>
	<form method="get" action="#searchGroupList">
		<div>
			<input type="text" name="q" placeholder="Recherche" value="<?=(isset($_REQUEST['q']) ? htmlspecialchars($_REQUEST['q']) : false);?>"> <input type="submit" name="subsearch" class="button-normal">
		</div>
	</form>
	<br>
	<br>
	<div align="left" id="searchGroupList">
		<!-- loading triangle -->
<?php 
$mp3_res = array(); $searched = false;
if(isset($_POST['q'])){ //sub1 is input[submit]'s attr 'name'
	extract($_POST);
	$searched = true;
	$q = htmlentities($q, ENT_QUOTES);
	
	$compter = $connect_bdd -> prepare("SELECT * FROM musics WHERE (artiste LIKE :q OR titre LIKE :q OR album LIKE :q OR label LIKE :q OR annee LIKE :q OR genre LIKE :q OR uploader LIKE :q) ");
	$s1 = $connect_bdd -> prepare("SELECT * FROM musics WHERE (artiste LIKE :q OR titre LIKE :q OR album LIKE :q OR label LIKE :q OR annee LIKE :q OR genre LIKE :q OR uploader LIKE :q) ");
	$s1 -> execute(array('q' => "%$q%"));
	$c1 = intval($s1 -> rowCount());
	$f1 = $s1 -> fetchAll(PDO::FETCH_OBJ);
	$s1 -> closeCursor();

	if($c1){
		$mp3_res['success'] = true;
		$mp3_res['found'] = $c1;
		$mp3_res['artiste'] = array();
		$mp3_res['titre'] = array();
		$mp3_res['code_name'] = array();
		$mp3_res['album'] = array();
		$mp3_res['pochette'] = array();
		foreach ($f1 as $found1) {
			if(!in_array($found1, $mp3_res)){
				$mp3_res['artiste'][] = $found1 -> artiste;
				$mp3_res['titre'][] = $found1 -> titre;
				$mp3_res['code_name'][] = $found1 -> code_name;
				$mp3_res['album'][] = $found1 -> album;
				$mp3_res['pochette'][] = $found1 -> pochette;
			}
		}
	}else{ // nothing found
		$mp3_res['success'] = false;
		$mp3_res['message'] = 'Aucun resultat pour '.$q;
	}
}

//search by genre
if(isset($_GET['genre'])){ //sub1 is input[submit]'s attr 'name'
	extract($_GET);
	$searched = true;
	$q = htmlentities($genre, ENT_QUOTES);
	
	$s1 = $connect_bdd -> prepare("SELECT * FROM musics WHERE genre LIKE :q");
	$s1 -> execute(array('q' => "%$q%"));
	$c1 = intval($s1 -> rowCount());
	$f1 = $s1 -> fetchAll(PDO::FETCH_OBJ);
	$s1 -> closeCursor();

	if($c1){
		$mp3_res['success'] = true;
		$mp3_res['found'] = $c1;
		$mp3_res['artiste'] = array();
		$mp3_res['titre'] = array();
		$mp3_res['code_name'] = array();
		$mp3_res['album'] = array();
		$mp3_res['pochette'] = array();
		foreach ($f1 as $found1) {
			if(!in_array($found1, $mp3_res)){
				$mp3_res['artiste'][] = $found1 -> artiste;
				$mp3_res['titre'][] = $found1 -> titre;
				$mp3_res['code_name'][] = $found1 -> code_name;
				$mp3_res['album'][] = $found1 -> album;
				$mp3_res['pochette'][] = $found1 -> pochette;
			}
		}
	}else{ // nothing found
		$mp3_res['success'] = false;
		$mp3_res['message'] = 'Aucun resultat pour '.$q;
	}
}
if($searched && $c1){ //searched and found
	echo '<div id="sIntro">'.$mp3_res['found'].' résultat/s pour <strong>'.$q.'</strong> </div>';
	for($i = 0; $i<count($mp3_res['titre']); $i++){
		?>

		<?php 
	}
}
?>
	</div>
</section>