<h2 id="tp100t"> 
	<img src="<?=ROOT_SANS;?>/img/icones/icons8-Add to Favorites.png" alt="" class="icon intitle"> Top 100 titres
</h2> 
<?php
$nb_elts = 100;
$ppge = 20;
$pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
$start = ($pg -1)*$ppge;
$nbpge = ceil($nb_elts/$ppge);
//get last $nb_elts added not under moderation
$sql = "SELECT * FROM musics WHERE moderation=0 ORDER BY hits DESC LIMIT $start, $ppge";
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<a href="<?=ROOT_SANS.'/about/'.$res['code_name'];?>" class="link2infos"> <?=$res['artiste'].' - '.$res['titre'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=$res['duree'];?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
		</div>
	<?php 
}
$stm -> closeCursor();

echo '<br><br>';
		echo '<center style="font-size:17pt;">';
                echo $nbpge.' page'.(($nbpge>1) ? 's' : false).' | &nbsp;';
                    for($j=$pg-8; $j<=$pg+8; $j++){
                        if($j>0 && $j<=floor($nb_elts/$ppge) && $j<=$nbpge){
                            if($j != $pg)
                                echo '<a href="'.ROOT_SANS.'/p/top-100/page-'.$j.'#tp100t"> '.$j.' </a>';
                            else
                                echo '<span> '.$j.' </span>';
                        }
                    }
        echo '</center>';

?>

<h2 id="tp100a"> 
	<img src="<?=ROOT_SANS;?>/img/icones/icons8-Add to Favorites.png" alt="" class="icon intitle"> Top 100 albums
</h2> 

<?php
$nb_elts = 100;
$ppge = 20;
$pg = (isset($_GET['page-2']) ? intval($_GET['page-2']) : 1);
$start = ($pg -1)*$ppge;
$nbpge = ceil($nb_elts/$ppge);

$sql = "SELECT * FROM albums WHERE moderation=0 ORDER BY hits DESC LIMIT $start, $ppge";
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<a href="<?=ROOT_SANS.'/album/'.$res['code_name'];?>" class="link2infos"> <?=$res['artiste'].' - '.$res['nom'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=count(explode(';',$res['id_titres']));?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
		</div>
	<?php 
}
$stm -> closeCursor();

echo '<br><br>';
		echo '<center style="font-size:17pt;">';
                echo $nbpge.' page'.(($nbpge>1) ? 's' : false).' | &nbsp;';
                    for($i=$pg-8; $i<=$pg+8; $i++){
                        if($i>0 && $i<=floor($nb_elts/$ppge) && $i<=$nbpge){
                            if($i != $pg)
                                echo '<a href="'.ROOT_SANS.'/p/top-100/partie-2/page-'.$i.'#tp100a"> '.$i.' </a>';
                            else
                                echo '<span> '.$i.' </span>';
                        }
                    }
        echo '</center>';
?>
