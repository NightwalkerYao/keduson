<div style="text-align:left;">
    &copy; <a href="//inspirates.io.ci/forums" target="_blank">Inspirates</a> - <?=date('Y');?> <br>
    <small>Theme and Code by <a target="_blank" href="//about.me/nightwalker.y"> The NightWalker Y</a>
    <br> Credit goes to <a href="//icons8.com" target="_blank">icons8.com</a>, <a href="http://jplayer.org" target="_blank">Jplayer.org</a> and Others!
    </small>
    <!--<br>
    Thanks to BGK Injecteur_Sqli-->
    <br> Please, read the <strong> <a href="<?=ROOT_SANS;?>/#disclaimer">Disclaimer</a> </strong>.
</div>
<div class="foot-en-2">
    <span><?=preg_replace('#https?://#i','',ROOT_SANS);?></span>
    made with <strong>:-)</strong> at home! <br>
    <?=counter_me(false);?> hits
</div>
<div>
    Retrouvez <?=preg_replace('#https?://#i','',ROOT_SANS);?> sur <br>
    <a href="//twitter.com/"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Twitter.png" alt="" width="58"> </a>
    <a href="//facebook.com/"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Facebook.png" alt="" width="58"> </a>
    <a href="//plus.google.com/"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Google Plus.png" alt="" width="58"> </a>
</div>
