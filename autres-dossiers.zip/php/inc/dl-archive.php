<?php 
if(isset($_GET['file'], $_SERVER['HTTP_REFERER'])){
    $f = $_GET['file'];
    $f = str_replace('../', '', $f);
    if(file_exists('../../zipped/'.$f.'.zip') && (strpos(strtolower($_SERVER['HTTP_REFERER']), '/about/') !== false || strpos(strtolower($_SERVER['HTTP_REFERER']), '/artist/') !== false || strpos(strtolower($_SERVER['HTTP_REFERER']), '/album/') !== false) ){
        $path = '../../zipped/'.$f.'.zip';
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$f.'.zip"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, GET-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: '.filesize($path));
        readfile($path);
        exit;
    }else{
        die("Vous n'êtes pas autorisés à télécharger ce fichier. / You are not allowed to download this file. #1");
    }
}else{
    die("Vous n'êtes pas autorisés à télécharger ce fichier. / You are not allowed to download this file. #2");
}
