<?php
$ppge = 30;
$pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
$start = ($pg -1)*$ppge;
$nbpge = ceil($nbtitres/$ppge);
//get last $nb_elts added not under moderation
$sql = "SELECT * FROM musics WHERE moderation=0 ORDER BY id DESC LIMIT $start, $ppge";
//echo $sql;
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<a href="<?=ROOT_SANS.'/about/'.$res['code_name'];?>" class="link2infos"> <?=$res['artiste'].' - '.$res['titre'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=$res['duree'];?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
		</div>
	<?php 
}
$stm -> closeCursor();
echo '<br><br>';
		echo '<center style="font-size:17pt;">';
                echo $nbpge.' page'.(($nbpge>1) ? 's' : false).' | &nbsp;';
                    for($i=$pg-8; $i<=$pg+8; $i++){
                        if($i>0 && $i<=$nbpge){
                            if($i != $pg)
                                echo '<a href="'.ROOT_SANS.'/p/downloads/page-'.$i.'"> '.$i.' </a>';
                            else
                                echo '<span> '.$i.' </span>';
                        }
                    }
        echo '</center>';
?>
