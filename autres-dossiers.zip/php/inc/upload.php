<?php
require_once('../config.php');
$out = array('intro' => 'work', 'message' => '');
$uploader = $_SESSION['uname'];

if(isset($_FILES['upfile']) && $_FILES['upfile']['error'] == 0){
    $filename = strip_tags($_FILES['upfile']['name']);
    $ext = pathinfo($filename,PATHINFO_EXTENSION);
    $store_name = uniqid();
    $store_name .= '.'.$ext;
    
    $all = "mp3 aac m4a wav ogg flac mid zip";
    $allowed = explode(' ', $all);
    if(in_array(strtolower($ext), $allowed)){
        if(!is_dir('../../temp_upz'))
            mkdir('../../temp_upz', 0777);
        $dir_path = '../../temp_upz/'.$store_name;
        if(move_uploaded_file($_FILES['upfile']['tmp_name'], $dir_path)){
            //save it in db here
            $save = $connect_bdd -> prepare('INSERT INTO temp_ups(file_name, store_name, uploader, date_upload) VALUES(:file_name, :store_name, :uploader, :date_upload)');
            $save -> execute(array('file_name'=> $filename, 'store_name'=>$store_name, 'uploader'=>$uploader, 'date_upload'=>time()));
            $id = $connect_bdd -> lastInsertId();
            $save -> closeCursor();
            
            $out["filename"]=$filename; 
            $out["end"]="success"; 
            $out["id"]=$id;
        }else{
            $out["filename"] = $filename; 
            $out["end"]="fail";
            $out["message"]="Une erreur s'est produite pendant la copie du fichier sur le serveur. Veillez reessayer. Si le problème persiste, contactez l'administration.";
        }
    }else{
        $out["end"]="fail";
        $out["message"]="Le fichier soumis n'est pas dans la liste des types autorisés. Merci de charger un fichier type audio.";
    }
}else{
    $out["end"]="fail";
    $out["message"]="L'upload du fichier ne s'est pas terminé correctement. Merci de reprendre.";
}

echo json_encode($out);

?>
