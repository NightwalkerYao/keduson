<?php
$nb_elts = 30;
//get last $nb_elts added not under moderation
$sql = "SELECT * FROM musics WHERE moderation=1 ORDER BY id DESC LIMIT $nb_elts";
$stm = $connect_bdd -> prepare($sql);
$stm -> execute(array($nb_elts));
while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<a href="<?=ROOT_SANS.'/about/'.$res['code_name'];?>" class="link2infos"> <?=$res['artiste'].' - '.$res['titre'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=$res['duree'];?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
		</div>
	<?php 
}
$stm -> closeCursor();
?>
