<section>
	<div align="left" id="searchGroupList">
		<!-- loading triangle -->
<?php 
if(isset($_REQUEST['q'])){

	$q = (array_key_exists($_REQUEST['q'], $genrs) ? $genrs[$_REQUEST['q']] : 'Rap');
	
	$q = htmlentities($q, ENT_QUOTES);

	$count = $connect_bdd -> prepare("SELECT COUNT(*) AS cnt FROM musics WHERE genre LIKE ? AND moderation=0 ");
	$count -> execute(array("%$q%"));// or die(print_r($count->errorInfo()));
	list($cnt) = $count -> fetch();
	$count -> closeCursor();
    //echo $cnt;
	if(intval($cnt)){
		//paging results...
		$nb_titre = intval($cnt);
		$ppge = 25;
		$pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
		$start = ($pg -1)*$ppge;
		$nbpge = ceil($cnt/$ppge);
		$stmt = "SELECT * FROM musics WHERE genre LIKE ? AND moderation=0 ORDER BY id DESC LIMIT $start,$ppge";
		$find = $connect_bdd -> prepare($stmt);
		//echo $stmt;
		$find -> execute(array("%$q%"));
		$res = $find -> fetchAll(PDO::FETCH_OBJ);
		$find -> closeCursor();
		echo '<font size="5" color="steelblue" face="Ubuntu"><b>.:: Morceaux ::. '.$cnt.'</b></font><br>';
		foreach ($res as $r) {
			?>
			<div class="mframe airbag" align="center">
				<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $r->pochette);?>" alt="image" style="width:130px; height: 120px;" >
				<br>
				<a href="<?=ROOT_SANS.'/about/'.$r->code_name;?>" class="link2infos"> <?=$r->artiste.' - '.$r->titre;?></a>
				<br>
				<small>
					<span class="trackduration remove-before-margin"><?=$r->duree;?></span> 
					<span class="trackdls"><?=$r->hits;?></span> 
					<span class="tracklk"><?=$r->likes;?></span> 
					<span class="trackcomm"><?=$r->commentaires;?></span>
				</small>
			</div>
			<?php 
		}
		echo '<br>';
		echo '<center style="font-size:17pt;">';
                echo $nbpge.' page'.(($nbpge>1) ? 's' : false).' | &nbsp;';
                    for($i=$pg-12; $i<=$pg+12; $i++){
                        if($i>0 && $i<=$nbpge){
                            if($i != $pg)
                                echo '<a href="'.ROOT_SANS.'/genre/'.htmlspecialchars($_REQUEST['q']).'/page-'.$i.'"> '.$i.' </a>';
                            else
                                echo '<span> '.$i.' </span>';
                        }
                    }
        echo '</center>';
	}else{ //nothing found
		echo '<font size="5" color="steelblue" face="Ubuntu"><b>.:: Morceaux ::.</b></font><br>';
		echo '<span style="color:orange; font-size: 13pt;">Aucun resultat !</span> <br>';
	}

	//query albums
	$count2 = $connect_bdd -> prepare("SELECT COUNT(*) AS cnt FROM albums WHERE genre LIKE ? AND moderation=0 ");
	$count2 -> execute(array("%$q%"));
	list($cnt2) = $count2 -> fetch();
	$count2 -> closeCursor();

	if(intval($cnt2)>0){
		//paging results...
		$nb_titre2 = intval($cnt2);
		$ppge2 = 20;
		$pg2 = (isset($_GET['page2']) ? intval($_GET['page2']) : 1);
		$start2 = ($pg2 -1)*$ppge2;

		$stmt2 = "SELECT * FROM albums WHERE genre LIKE ? AND moderation=0 ORDER BY id DESC LIMIT $start2,$ppge2";
		$find2 = $connect_bdd -> prepare($stmt2);
		$find2 -> execute(array("%$q%"));
		$res2 = $find2 -> fetchAll(PDO::FETCH_OBJ);
		$find2 -> closeCursor();
		echo '<br> <br> <font size="5" color="steelblue" face="Ubuntu"><b>.:: Albums ::. '.$cnt2.'</b></font><br>';
		foreach ($res2 as $r2) {
			?>
			<div class="mframe airbag" align="center">
				<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $r2->pochette);?>" alt="image" style="width:130px; height: 135px;" >
				<br>
				<a href="<?=ROOT_SANS.'/album/'.$r2->code_name;?>" class="link2infos"> <?=$r2->artiste.' - '.$r2->nom;?></a>
				<br>
				<small>
					<span class="trackduration remove-before-margin"><?=count(explode(';', $r2->id_titres));?></span> 
					<span class="trackdls"><?=$r2->hits;?></span> 
					<span class="tracklk"><?=$r2->likes;?></span> 
					<span class="trackcomm"><?=$r2->commentaires;?></span>
				</small>
			</div>
			<?php 
		}
	}else{ //nothing found
		echo '<font size="5" color="steelblue" face="Ubuntu"><b>.:: Albums ::.</b></font><br>';
		echo '<span style="color:orange; font-size: 13pt;">Aucun resultat !</span> <br>';
	}
	
}
?>
	</div>
</section>
