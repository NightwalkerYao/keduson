<?php 
if(isset($_GET['id'], $_SERVER['HTTP_REFERER'])){
    require_once('../config.php');
    $id = urlencode_2($_GET['id']);
    $ref = $_SERVER['HTTP_REFERER'];
    $the_ref = '/about/'.$id; //must be from here to ddl.
    
    //check the HTTP_REFERER before processing to ddl.
    //if not from the details page, redirect to title's details
    //else go ddl.
    if(strpos($ref, $the_ref) !== false){
        $exist = $connect_bdd -> prepare('SELECT * FROM musics WHERE code_name=? AND moderation=0 LIMIT 1');
        $exist -> execute(array($id));
        $found = intval($exist -> rowCount());
        $t = $exist -> fetch();
        $exist -> closeCursor();
    
        if($found){
            $path = '../../files/'.$t['nom_fichier'];
            if(file_exists($path)){
                $setdl = $connect_bdd -> prepare('UPDATE musics SET hits=hits+1 WHERE code_name=? LIMIT 1');
                $setdl -> execute(array($id));
                $setdl -> closeCursor();
                
                $ext = pathinfo($t['nom_fichier'], PATHINFO_EXTENSION);
                $o = '';
                //$o .= $t['id'];
                //$o .= '_';
                $o .= html_entity_decode($t['artiste']);
                $o .= '-';
                $o .= html_entity_decode($t['titre']);
                $o .= '[www.musicbox.cf]';
                $o .= '.';
                $o .= $ext;
                $o = strip_tags($o);
            
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="'.$o.'"');
                header('Content-Transfer-Encoding: binary');
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                header('Content-Length: '.filesize($path));
                readfile($path);
                exit;
            }else{
                die("Ce fichier n'existe plus. Merci de signaler un lien mort aux administrateurs.");
            }
        }else{
            die("Ce fichier n'est pas dans la liste des telechargements autoris3s.");
        }
    }else{
        header('Location: '.ROOT_SANS.$the_ref);
        exit;
    }
}else{
    die("Cette page fonctionne pas comme pr3vu. Vous avez peut etre manqu3 des trucs.. Revenez demain svp.");
}
?>
