<div>
	<br>
	<br>
	<img src="<?=ROOT_SANS;?>/img/icones/icons8-Error.png" alt="" class="error-img"> 
	<div class="error-msg">
		<span class="error-text"> Erreur 404 : Désolé, cette page n'existe pas. </span> 
		<br>
		<small> Ceci est une page d'erreur. Vous allez être redirigé à la page d'accueil dans <span id="erTO">7</span> secondes...</small>
	</div>
</div>

<script type="text/javascript">
	window.onload = function(){
		var t=7, t_int = setInterval(function(){
			document.getElementById('erTO').innerText = t;
			t--;
			if(t<0)
				clearInterval(t_int)
		}, 1000);

		var t_out = setTimeout(function(){
			window.location = ROOT_SANS+'/';
		}, t*1000);
	};
</script>