<?php
//case artist not found
if($a == 0){
        include_once('error.php');
}else{
	echo '<form method="POST" action="'.ROOT_SANS.'/" id="zip_n_dl">';
	while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<!--chkbx is here!-->
			<input type="checkbox" name="elts[]" class="elementTitle" value="<?=$res['nom_fichier'];?>">
			
			<a href="<?=ROOT_SANS.'/about/'.$res['code_name'];?>" class="link2infos"> <?=$res['titre'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=$res['duree'];?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
			<br>
			<small> <?=$res['album'];?> </small>
		</div>
	<?php 
	}
	$stm -> closeCursor();
	?>
	<br>
        <div id="albtoolbar"> 
            <span class="albliketitle"> Sélection </span>  
            <button type="button" id="artAllselect" class="button-actionbar" data-title="<?=$artiste;?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Checkmark.png" alt="" class="icon incontent"> Tout sélectionner 
            </button>
            <input type="checkbox" name="checkall" value="0" id="chkAll" style="display:none;" >
            <button type="button" id="aristSelectPlay" class="button-actionbar"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Play Album.png" alt="" class="icon incontent"> Jouer 
            </button> 
            <button type="submit" id="artMass_dl" class="button-actionbar">
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Downloads.png" alt="" class="icon incontent"> Télécharger 
            </button> 
        </div>
    </form>

        <div id="seemore"> 
        <h2> 
            <img src="<?=ROOT_SANS;?>/img/icones/icons8-Add Album.png" alt="" class="icon intitle"> Albums par <?=$artiste;?>
        </h2> 
        <ul> 
            <?php
            $getsug = $connect_bdd -> prepare('SELECT * FROM albums WHERE artiste=? AND moderation=0');
            $getsug -> execute(array($artiste)) or die('broken!');

            $lim = intval($getsug -> rowCount()); //fetched elements
            while($dd = $getsug -> fetch()){
            	//print_r($dd);
                ?>
                <li style="text-align: center;">
                    <a href="<?=ROOT_SANS.'/album/'.$dd['code_name'];?>">
                        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $dd['pochette']);?>" alt="<?=$dd['artiste'].' - '.strip_tags($dd['nom']);?>" width="90%">
                        <br>
                        <?=$dd['nom'];?>
                    </a>
                </li>
                <?php
            }
            $getsug -> closeCursor();
            if(!$lim)
                echo '<span> Aucun album disponible </span>';
            ?>
        </ul> 
    </div>
    <?php
}
?>
