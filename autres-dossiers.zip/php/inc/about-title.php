<?php
    //cas le titre n'est pas trouve
    if($c != 1){
        include_once('error.php');
    }else{
        ?>
        <div class="albcorps contain-dbl"> 
            <div id="albcover"> 
                <img src="<?=ROOT_SANS;?>/covers/<?=$d['pochette'];?>" alt="<?=$d['artiste'].' '.$d['titre'];?>" id="coverable"> 
            </div> 
            <div id="albinfos"> 
                <h3 class="home-sec-ttle"> <?=$d['artiste'] .' - '.$d['titre'];?> </h3>
                <small> <?=$d['label'];?> </small> 
                <br>
                <span id="albauthor"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-DJ.png" alt="" class="icon incontent"> 
                    <a href="<?=ROOT_SANS;?>/artist/<?=urlencode(html_entity_decode($d['artiste']));?>"><?=$d['artiste'];?></a> 
                </span> 
                <br> 
                <span id="albyear"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/7-48.png" alt="" class="icon incontent"> <?=(intval($d['annee']) ? $d['annee'] : date('Y'));?>
                </span> 
                <span id="albgenre"> &nbsp; &nbsp; 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Rock Music.png" alt="" class="icon incontent"> <a href="<?=ROOT_SANS.'/search?genre='.urlencode(html_entity_decode($d['genre']));?>"><?=$d['genre'];?></a>
                </span> 
                <br> 
                <span id="albnname"> 
<?php //get the true name of the album
$true_alb_name = '';
$album_name = $connect_bdd -> prepare('SELECT nom FROM albums WHERE code_name=? ORDER BY id DESC LIMIT 1');
$album_name -> execute(array(htmlentities($d['album'], ENT_QUOTES)));
list($result) = $album_name -> fetch();
$album_name -> closeCursor();
$true_alb_name .= $result;

if(trim($true_alb_name) != '') {
    ?>
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Music Album.png" alt="" class="icon incontent"> <a href="<?=ROOT_SANS;?>/album/<?=urlencode(html_entity_decode($d['album']));?>"><?=$true_alb_name;?></a>  &nbsp; &nbsp;
    <?php }
    else{
    ?>
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Music Album.png" alt="" class="icon incontent"> <?=$d['album'];?></a>  &nbsp; &nbsp;
    <?php 
    }
?>
                </span>
                <br>
                <span id="albnbtitles"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Audio File.png" alt="" class="icon incontent"> Piste N°<?=(intval($d['piste']) ? $d['piste'] : 1);?>  
                </span> 
                <br> 
                <span id="albduration"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Stopwatch_50.png" alt="" class="icon incontent"> <?=$d['duree'];?> &nbsp; &nbsp; 
                </span> 
                <br>
                <span id="albsize"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-International Music.png" alt="" class="icon incontent"> <?=round(intval($d['taille'])/bcpow(2, 20),2);?> Mo
                </span> 
                <br> 
                <span id="albdls"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Download.png" alt="" class="icon incontent"> <?=$d['hits'];?> Téléchargements 
                </span> 
                <br> 
                <span id="albcomm"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Comments.png" alt="" class="icon incontent"> <?=$d['commentaires'];?> commentaires 
                </span> 
                <br> 
                <span id="albuploader"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-technical support.png" alt="" class="icon incontent"> 
                    <small>par </small> 
                    <a href="<?=ROOT_SANS;?>/user/<?=urlencode($d['uploader']);?>"> <?=$d['uploader'];?> </a> le <?=date('d/m/Y',$d['date_upload']);?>
                </span> 
            </div> 
        </div>  

        <br>
        <div id="tileBuy">
                            <div>
                                <div id="external_buy_links">
                                <span>Acheter</span> &nbsp; &nbsp; &nbsp;
                                    <a title="Acheter sur Itunes" target="_blank" href="https://google.com/search?q=site:itunes.apple.com+<?=urlencode($d['artiste'].' '.$d['titre']);?>"> <img src="<?=ROOT_SANS;?>/img/itunes.png" alt="Itunes"></a>
                                    <a title="Acheter sur Amazon" target="_blank" href="https://music.amazon.com/search/<?=urlencode($d['artiste'].' '.$d['titre']);?>"> <img src="<?=ROOT_SANS;?>/img/amazon.jpg"></a>
                                    <a title="Acheter sur Google Play Music" target="_blank" href="https://play.google.com/store/search?q=<?=urlencode($d['artiste'].' '.$d['titre']);?>&c=music"> <img src="<?=ROOT_SANS;?>/img/play-music.png"></a>
                                    <a title="Acheter sur Qobuz" target="_blank" href="https://www.qobuz.com/fr-fr/search?q=<?=urlencode($d['artiste'].' '.$d['titre']);?>&i=boutique"><img src="<?=ROOT_SANS;?>/img/qobuz.jpg"></a>
                                </div>
                            </div>
                        </div>
                        <br>

        <div id="albtoolbar"> 
            <span class="albliketitle"> Actions </span>  
            <button type="button" id="albplay" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Play Album.png" alt="" class="icon incontent"> Jouer 
            </button> 
            <button type="button" id="ttleaddlike" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Heart.png" alt="" class="icon incontent"> <span id="nbtlikes"><?=$d['likes'];?></span> 
            </button> 
            <button type="button" id="ttleadddislike" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Thumbs Down.png" alt="" class="icon incontent"> <span id="nbtdislikes"><?=$d['dislikes'];?></span>
            </button> 
            <a href="<?=ROOT_SANS;?>/ddl/<?=$d['code_name'];?>"> <button type="button" id="albdl" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Downloads.png" alt="" class="icon incontent"> Télécharger 
            </button> </a>
            <button type="button" id="ttleshare" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Share.png" alt="" class="icon incontent"> Partager 
            </button> 
            <a href="#addComment" id="go2cmnt"> <button type="button" id="albaddcomment" class="button-actionbar" data-title="<?=$d['code_name'];?>"> 
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-Comments_2.png" alt="" class="icon incontent"> Commenter (<?=$d['commentaires'];?>)
            </button> </a>
            <div id="shareDialog" style="display:none; text-align:center;" title="Partager <?=$d['artiste'].' - '.$d['titre'];?>">
                <h2>Partager <?=$d['artiste'].' - '.$d['titre'];?> <br>avec</h2>
                <br>
                <a href="//twitter.com/intent/tweet?text=<?=urlencode("Télécharger et écouter ".html_entity_decode($d['artiste'].' - '.$d['titre']));?>&url=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']); ?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Twitter.png" alt=""> </a>
                <a href="//facebook.com/sharer.php?u=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']);?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Facebook.png" alt=""> </a>
                <a href="//plus.google.com/share?url=<?=urlencode(ROOT_SANS.$_SERVER['REQUEST_URI']); ?>"> <img src="<?=ROOT_SANS;?>/img/icones/icons8-Google Plus.png" alt=""> </a>
            </div>
        </div>

        <div id="keyword_s" align="left" class="contain-dbl">
            <h2 class="home-sec-ttle">Tags</h2>
            <p style="padding:0.3em;">
                <?php
                    echo "Ecouter $d[artiste] $d[titre] , $d[genre], Telecharger $d[artiste] $d[titre] mp3 gratuit, Download $d[artiste] $d[titre] free, $d[artiste] $d[album] album complet, $d[annee], Nouveautés ".date('Y')." de $d[artiste], mp3 gratuit, aac, m4a, flac, zip, torrent , Streetzik.net , music, streaming $d[artiste], les sons de $d[label], upload par $d[uploader], direct downolad music, Musicbox.cf Team $d[artiste] $d[titre].mp3 , Index of $d[artiste] mp3 Tous les telechargements de musique sur www.Streetzik.net";
                ?>
            </p>
        </div>

        <div id="artmore">
            <h2>
                <img src="<?=ROOT_SANS;?>/img/icones/icons8-DJ.png" alt="" class="icon intitle"><?=$d['artiste'];?>
                <?php
                $artitr = $connect_bdd -> prepare('SELECT COUNT(*) AS nb FROM musics WHERE artiste=? AND moderation=0');
                $artitr -> execute(array($d['artiste']));
                list($anb) = $artitr -> fetch();
                $artitr -> closeCursor();
                ?>
            </h2>
            <span id="arttrackz"> 
                <span> <?=$anb;?> titres </span> 
                <br> 
                <a href="<?=ROOT_SANS.'/artist/'.urlencode($d['artiste']);?>" class="button-actionbar" data-artist="<?=$d['artiste'];?>">
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Music Album.png" alt="" class="incontent icon"> Tout voir 
                </a> 
                <a href="<?=ROOT_SANS.'/mass-dl/'.urlencode($d['artiste']);?>" class="button-actionbar" data-artist="<?=$d['artiste'];?>" id="artDlAllFrom"> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Create Archive.png" alt="" class="incontent icon"> Tout télécharger 
                </a> 
                <div id="dlAllProcessDialog" title="Télécharger tout de <?=$d['artiste'];?>" style="display:none; text-align:center;">
                    <h2 id="massDlStatus">Préparation du téléchargement..</h2>
                    <br>
                    <img src="<?=ROOT_SANS;?>/img/Load.gif" alt="" width="100" id="dialoader"> 
                    <br>
                    <span id="massDlStext">Récupération de la liste des fichiers.</span>
                </div>
            </span>
        </div>

    <div id="seemore" class="contain-dbl"> 
        <h2 class="home-sec-ttle" style="text-align: left; "> 
            <img src="<?=ROOT_SANS;?>/img/icones/icons8-Add Album.png" alt="" width="36"> D'autres titres
        </h2> 
        <ul> 
            <?php
            $getsug = $connect_bdd -> prepare('SELECT * FROM musics WHERE code_name!=? AND genre LIKE ? AND moderation=0 ORDER BY id DESC LIMIT 5');
            $getsug -> execute(array($d['code_name'], '%'.$d['genre'].'%'));

            $lim = intval($getsug -> rowCount()); //fetched elements
            while ($dd = $getsug -> fetch()) {
                ?>
                <li style="text-align: center;">
                    <a href="<?=ROOT_SANS.'/about/'.$dd['code_name'];?>">
                        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $dd['pochette']);?>" alt="<?=$dd['artiste'].' - '.$dd['titre'];?>" width="90%">
                        <br>
                        <?=$dd['artiste'].' - '.$dd['titre'];?>
                    </a>
                </li>
                    <?php
            }
            $getsug -> closeCursor();

            if($lim < 5){ //less than 5 elements got. another query to complete to 5 rows total.
               $rest = 5-$lim;
                $sql = 'SELECT * FROM musics WHERE code_name!=? AND genre NOT LIKE ? AND moderation=0 ORDER BY id DESC LIMIT '.$rest;
                $getsug2 = $connect_bdd -> prepare($rest);
                $getsug2 -> execute(array($d['code_name'], '%'.$d['genre'].'%'));

                while ($dd2 = $getsug2 -> fetch()) {
                ?>
                <li style="text-align: center;">
                    <a href="<?=ROOT_SANS.'/about/'.$dd2['code_name'];?>">
                        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $dd2['pochette']);?>" alt="<?=$dd2['artiste'].' - '.$dd2['titre'];?>" width="125">
                        <br>
                        <?=$dd2['artiste'].' - '.$dd2['titre'];?>
                    </a>
                </li>
                <?php
            }
            $getsug2 -> closeCursor();
            }

            ?>
        </ul> 
    </div>

    <div id="docomments" class="contain-dbl">
<?php
    $comms = $connect_bdd -> prepare('SELECT * FROM music_comments WHERE titre_cn=?');
    $comms -> execute(array(htmlentities($d['code_name'], ENT_QUOTES)));
    $nb_coms = $comms -> rowCount();
?> 
        <h2 class="home-sec-ttle"> 
            <img src="<?=ROOT_SANS;?>/img/icones/icons8-Comments_50.png" alt=""> Commentaires (<?=$nb_coms;?>)
        </h2> 
        <form id="addComment" method="post" action="#comment_<?=$nb_coms+1;?>"> 
            <div style="padding-left: 5px;"> 
                <label for="username" class="libelef">Identifiant: 
                </label> 
                <br> 
                <input type="text" name="username" id="username" class="midlleinput" value="<?=$_SESSION['uname'];?>" readonly> 
                <input type="hidden" name="title_cn" value="<?=$d['code_name'];?>">
                <br> 
                <label for="comment" class="libelef">Message: 
                </label> 
                <br> 
                <textarea id="comment" rows="4" name="text"></textarea> 
                <br> 
                <br> 
                <!-- <input type="hidden" name="albumId" value="abcdef" id="albumId">&nbsp; &nbsp; &nbsp;  -->
                <input type="submit" value="Soumettre" id="subcomment" class="button-normal"> 
            </div> 
        </form> 
        <table id="comment_">
            <?php
            $pp=1;
            while($cm = $comms -> fetch()){
                ?>
            <tr id="comment_<?=$cm['id'];?>"> 
                <td> 
                    <img src="<?=ROOT_SANS;?>/img/icones/icons8-Boombox.png" alt=""> 
                    <!-- <br> -->
                    <a href="<?=ROOT_SANS.'/user/'.urlencode($cm['auteur']);?>"><?=$cm['auteur'];?></a>
                </td> 
                <td> <?=nl2br(htmlspecialchars($cm['texte']));?>
                    <br>
                    <small><i>Commentaire N°<?=$pp;?> - le <?=date('d/m/Y \à H:i', $cm['date_post']);?> </i></small>
                </td> 
            </tr> 
            <?php
            $pp++;
            }
            $comms -> closeCursor();
            ?>
        </table> 
    </div>

<?php
}
?>
