<h2> 
	<img src="<?=ROOT_SANS;?>/img/icones/icons8-Add Album.png" alt="" class="icon intitle"> Albums
</h2> 
<?php
$ppge = 25;
$pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
$start = ($pg -1)*$ppge;
$nbpge = ceil($nbalbums/$ppge);

$sql = "SELECT * FROM albums WHERE moderation=0 ORDER BY id DESC LIMIT $start,$ppge";
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
	?>
		<div class="mframe airbag">
			<img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="image" style="width:130px; height: 120px;" >
			<br>
			<a href="<?=ROOT_SANS.'/album/'.$res['code_name'];?>" class="link2infos"> <?=$res['artiste'].' - '.$res['nom'];?></a>
			<br>
			<small>
				<span class="trackduration remove-before-margin"><?=count(explode(';',$res['id_titres']));?></span> 
				<span class="trackdls"><?=$res['hits'];?></span> 
				<span class="tracklk"><?=$res['likes'];?></span> 
				<span class="trackcomm"><?=$res['commentaires'];?></span>
			</small>
		</div>
	<?php 
}
$stm -> closeCursor();

echo '<br><br>';
		echo '<center style="font-size:17pt;">';
                echo $nbpge.' page'.(($nbpge>1) ? 's' : false).' | &nbsp;';
                    for($i=$pg-8; $i<=$pg+8; $i++){
                        if($i>0 && $i<=$nbpge){
                            if($i != $pg)
                                echo '<a href="'.ROOT_SANS.'/p/albums/page-'.$i.'"> '.$i.' </a>';
                            else
                                echo '<span> '.$i.' </span>';
                        }
                    }
        echo '</center>';
?>
