<?php
  require_once("../php/config.php");
  counter_me(true);
?>
<!DOCTYPE html>
<html lang="fr-CI">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<meta name="author" content="Club KDS" >
<title><?=$_TITRE;?></title>
<meta name="description" content="<?=$_META_DESCRIPTION;?>" />
<meta name="keywords" content="<?=$_META_KEYWORDS;?>" />
<!-- ogs -->
<meta property="og:url" content="<?=$_OG_URL;?>" />
<meta property="og:title" content="<?=$_OG_TITLE;?>" />
<meta property="og:description" content="<?=$_OG_DESCRIPTION;?>" />
<meta property="og:type" content="<?=$_OG_TYPE;?>" />
<meta property="og:image" content="<?=$_OG_IMAGE;?>" />
<meta property="og:site_name" content="<?=$_OG_SITE_NAME;?>" />
<link rel="alternate" type="application/rss+xml" title="Flux RSS" href="<?=ROOT_SANS;?>/rss.xml" />
<link rel="stylesheet" type="text/css" href="<?=MOBILE_BASE;?>/asset/css/font.css" />
<link rel="stylesheet" type="text/css" href="<?=MOBILE_BASE;?>/asset/css/materialize.min.css" />
<link rel="icon" href="<?=ROOT_SANS;?>/s.png" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="<?=ROOT_SANS;?>/css/pagination.css" />
<script type="text/javascript">
	var ROOT_SANS = '<?=ROOT_SANS;?>';
</script>
</head>
<body style="background-color: #fff;">

	<header>
		<div class="navbar-fixed">
		    <nav>
		      <div class="nav-wrapper orange">
		        <a href="<?=MOBILE_BASE;?>" class="brand-logo left">KEDUSON</a>
		        <ul class="right">
		          <li><a href="<?=ROOT_SANS;?>/club">Club</a></li>
		          <li><a href="<?=MOBILE_BASE;?>/ajouter">Ajouter</a></li>
		          <li><a href="<?=MOBILE_BASE;?>/tops">Top 100</a></li>
		        </ul>
		      </div>
		    </nav>
		</div>
		<nav class="transparent">
		    <div class="nav-wrapper" style="margin: 10px 0 0 0;">
		      <form action="<?=M_SEARCH_BASE;?>">
		      	<!-- <div class="row s12"> -->
		        <div class="input-field" style="position: relative;">
		          <input id="search" type="search" name="q" required class="autocomplete" autocomplete="off" value="<?=isset($_REQUEST['q']) ? htmlspecialchars($_REQUEST['q']) : false;?>">
		          <label class="label-icon" for="search"><i class="material-icons orange-text">search</i></label>
		          <!-- <i class="material-icons">close</i> -->
		          <button type="submit" class="btn btn-flat waves-effect waves-light white-text orange" style="position: absolute; top: 10px; right: 10px;">OK</button>
		        </div>
		        <!-- <div class="col s2">
		        	<button type="submit" class="btn btn-flat waves-effect waves-light white-text orange">OK</button>
		        </div> -->
		    <!-- </div> -->
		    	<input type="hidden" name="content" value="search">
		      </form>
		    </div>
		</nav>
	</header>

	<main style="padding: 0 0.4em;">
	<?php
      if(isset($_GET['content'])){
        $content = $_GET['content'];
        $allowed_contents = scandir('./content');
        if($content != '.' && $content != '..' && in_array($content.'.php', $allowed_contents)){
          @include_once('./content/'.$content.'.php');
        }else{
            @include_once('./content/error.php');
        }
      }else{
        @include_once('./content/default.php');
      }
    ?>
	</main>
	<div class="divider white"></div>
	<footer class="page-footer transparent" style="margin:0; padding: 0;">
		<nav class="orange lighten-1" style="height: auto; overflow: hidden; text-transform: uppercase; margin: 0;">
	    <center class="nav-wrapper center">
	      <ul>
	        <li><a href="<?=MOBILE_BASE;?>/genre/hip-hop/">Hip-Hop / Rap</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/couper-decaler/">Couper-Decaler</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/zouglou/">Zouglou</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/afrobeat/">AfroBeat</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/reggae/">Reggae</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/gospel/">Gospel</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/afropop/">Afropop</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/rnb/">R&amp;b / soul</a></li>
            <li><a href="<?=MOBILE_BASE;?>/genre/folk/">Variétés</a></li>
	      </ul>
	    </center>
	  </nav>
	  <div class="footer-copyright orange" style="margin: 0;">
        	<div class="container" style="margin-top: 0; margin-bottom: 0;">
            	<span class="left"> &copy; 2018 <a class="white-text" href="//inspirates.io.ci/">Inspirates</a></span>
            </div>
        </div>
    </footer>
<script type="text/javascript" src="<?=MOBILE_BASE;?>/asset/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="<?=MOBILE_BASE;?>/asset/js/materialize.min.js"></script>
  <script type="text/javascript" src="<?=ROOT_SANS;?>/js/boutons.js"></script>
  <script type="text/javascript" src="<?=MOBILE_BASE;?>/asset/js/ac0.js"></script>
<script type="text/javascript">
<?php
//built-in anti-adblock
//list of fake blockable files
//$.ajax('showads.js').fail(function(d){if(d.status===0 || d.statusText == 'error'){$('html').addClass('ab');}});
$fkjs = ['royalads', 'afrikad', 'banner', 'adv', 'clikyads', 'payclick', 'popunder', 'go4ads', 'adsense', 'exads', 'mediaads', 'doucleclickads'];
?>
$(document).ready(function(){
	$.ajax({
		url: '/mobile/<?=$fkjs[mt_rand(0,count($fkjs)-1)];?>/displayads.js',
		type: 'get',
		dataType: 'json',
		data: {'zoneID': <?=mt_rand();?>, 'siteID': 5897565},
		error: function(er){
			if(er.status ===0 || er.status=='error'){
				$('main').html([
					'<div class="red white-text"><br><br>',
					'<div class="flow-text container center" style="font-size: 18pt;">',
					'<h3><u>Bloqueur de publicités détecté.</u></h3>',
					'Soutenez-nous en le désactivant <br><br>',
					'Actualisez cette page ensuite.',
					'</div><br><br>',
					'</div>'
				].join(' '));
			}
		}
	})
});
var instancei = M.Tabs.init(document.querySelector('.tabs'), {
	swipeable: false
});

var elem = document.querySelector('.autocomplete');
var instance = M.Autocomplete.init(elem, {
	data: acdat0, 
	limit:7,
	minLength: 1
	 });
//process to update autocomplete data list
var full_ac = false; //avoid reloading the full ac jsfile(+500kb)
$('#search').on('keyup', function(){
	if($(this).val().trim().length>=5){
		if(!full_ac){
			var q = $(this).val().trim();
			$.ajax({
				url: ROOT_SANS+'/mobile/asset/js/ac.js',
				data: {'q': q, 'dev': 'mobile'},
				dataType: 'json',
				type: 'GET',
				success: function(res){
					full_ac = res.got;
					instance.updateData(res.liste);
				}
			})
		}
	}else{
		instance.updateData(acdat0);
		full_ac = false;
	}
})
</script>
<?php
//write a js file for search autocomplete quickly
// 1. only artists names
if(isset($_REQUEST['ac0'])){
	$artsts = $connect_bdd -> query("SELECT DISTINCT(artiste),pochette FROM musics WHERE moderation=0 ORDER BY artiste ASC");
	$txt = [];
	while($t = $artsts->fetch()){
		$txt[$t['artiste']] = ROOT_SANS.'/covers/'.str_replace('500X500', '65X65', $t['pochette']);
	}
	$artsts -> closeCursor();
	file_put_contents(PHP_ROOT.'/mobile/asset/js/ac0.js', 'var acdat0 = '.json_encode($txt));
	echo '<div class="container green white-text flow-text">Le fichier des artistes a ete maj!</div>';
}
// 2. Full autocompletion: artiste - titre - cover
if(isset($_REQUEST['ac1'])){
	$artsts = $connect_bdd -> query("SELECT artiste,titre,pochette FROM musics WHERE moderation=0");
	$txt = [];
	$txt['liste'] = [];
	while($t = $artsts->fetch()){
		$txt['liste'][$t['artiste'].' '.$t['titre']] = ROOT_SANS.'/covers/'.str_replace('500X500', '65X65', $t['pochette']);
	}
	$artsts -> closeCursor();
	$txt['got'] = true;
	file_put_contents(PHP_ROOT.'/mobile/asset/js/ac.js', json_encode($txt));
	echo '<div class="container green white-text flow-text">Le fichier full-autocomplete a ete maj!</div>';
}?>
</body>
</html>