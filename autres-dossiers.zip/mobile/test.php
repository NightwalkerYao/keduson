<?php
$a = "bonjour";
echo $a.'<br>';
echo 'end $a = '.substr($a, -1);
echo '<br>';
echo substr($a, 0, strlen($a)-1);
echo '<br>';
echo $_SERVER['REQUEST_URI'];