<br>
    <center class="s12 container"><img class="responsive-img" src="<?=ROOT_SANS;?>/logo.jpg" alt=""></center>
<div style="background-color:#191919;">
  <!-- publicites -->
</div>
<h1 style="font-size: 28pt;" class="light-blue-text center">Nouveautés KDS</h1>
<div class="divider grey"></div>
<ul class="collection" style="z-index: 0;">
<?php
$stm = $connect_bdd->query("SELECT COUNT(*) AS nb FROM musics WHERE moderation=0");
list($nbtitres) = $stm->fetch();
$stm->closeCursor();
$ppge = 50;
$pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
$start = ($pg -1)*$ppge;
$nbpge = ceil($nbtitres/$ppge);
//get last $nb_elts added not under moderation
$sql = "SELECT * FROM musics WHERE moderation=0 ORDER BY id DESC LIMIT $start, $ppge";
//echo $sql;
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
  ?>
  <li class="collection-item avatar">
      <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '65X65', $res['pochette']);?>" alt="" class="circle" style="width: 65px; height: 65px;">
      </a> &nbsp; &nbsp;
      <span class="title">
        <a class="orange-text" href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
          <?=$res['artiste'].' - '.$res['titre'];?>
        </a>
      </span>
      <p>&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; <?=$res['hits'];?> hits - <?=$res['duree'];?> - <?=round($res['taille']/pow(2, 20), 2);?>Mo <br>
        &nbsp;&nbsp; &nbsp;&nbsp; <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">Ecouter</a> | <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">Télécharger</a> </p>
      <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>" class="secondary-content"><i><img src="<?=MOBILE_BASE;?>/asset/png/32/arrow_down.png"></i></a>
  </li>
<?php }
$stm -> closeCursor();
?>
</ul>              

<div class="paginate center">
<?php
$previousy = ($pg == 1) ? '<span class="disabled">&lt;</span>' : '<a href="'.MOBILE_BASE.'/telechargements/page-'.($pg-1).'">&lt;</a>';
echo $previousy;
if(($pg-2)>4){
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-1">1</a>';
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-2">2</a>';
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-3">3</a>';
  echo '...';
}
for($i=$pg-2; $i<= $pg+2; $i++) {
  if($i==$pg)
    echo '<span class="current">'.$i.'</span>';
  elseif($i>0 && $i<=$nbpge)
    echo '<a href="'.MOBILE_BASE.'/telechargements/page-'.$i.'">'.$i.'</a>';
}
if(($nbpge-3)>($pg+2)){
  echo '...';
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-'.($nbpge-2).'">'.($nbpge-2).'</a>';
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-'.($nbpge-1).'">'.($nbpge-1).'</a>';
  echo '<a href="'.MOBILE_BASE.'/telechargements/page-'.($nbpge).'">'.($nbpge).'</a>';
}
$nexty = ($pg == $nbpge) ? '<span class="disabled">&gt;</span>' : '<a href="'.MOBILE_BASE.'/telechargements/page-'.($pg+1).'">&gt;</a>';
echo $nexty;
?>            
</div>
<br>
<div class="divider orange"></div>
<h2 style="font-size: 20pt;" class="light-blue-text center">Derniers albums</h2>
<div class="belter center">
<?php 
  $lalb = $connect_bdd -> prepare('SELECT artiste, nom,code_name,annee,pochette FROM albums WHERE moderation=0 ORDER BY id DESC LIMIT 15');
  $lalb -> execute();
  while($lG = $lalb->fetch()){ ?>
  <div class="card-panel">
    <a href="<?=M_ABOUT_ALBUM.'/'.$lG['code_name'];?>/" title="<?=$lG['artiste'].' - '.$lG['nom'].' ('.$lG['annee'].')';?>">
      <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $lG['pochette']);?>" alt="<?=$lG['artiste'].' - '.$lG['nom'];?>" height="150" width="200">
      <br>
      <span><?=$lG['artiste'].' - '.$lG['nom'].'('.$lG['annee'].')';?></span>
    </a>
    <!-- <div class="ozet"></div> -->
  </div>
  <?php }
    $lalb->closeCursor();
?>
</div>