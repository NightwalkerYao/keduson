<?php
$stm = $connect_bdd->prepare("SELECT COUNT(*) AS nbr FROM musics WHERE MATCH (artiste, titre, album, genre, label) AGAINST (?) AND moderation=0");
$stm -> execute(array(het($_GET['q'])));
list($nbtitres) = $stm->fetch();
$stm->closeCursor();

$stm2 = $connect_bdd->prepare("SELECT COUNT(*) AS nbr FROM albums WHERE MATCH (artiste, nom, label, genre) AGAINST (?) AND moderation=0");
$stm2 -> execute(array(het($_GET['q'])));
list($nbtitres2) = $stm2->fetch();
$stm2->closeCursor();
?>
<br>
<div class="row s12">
  <div class="col s12">
    <ul class="tabs">
      <li class="tab s6"><a href="#searchsingles" class="orange-text active">Morceaux (<?=$nbtitres;?>)</a></li>
      <li class="tab s6"><a href="#searchalbums" class="orange-text">Albums (<?=$nbtitres2;?>)</a></li>
    </ul>
  </div>
<?php
//if($nbtitres){
  $ppge = 40;
  $pg = (isset($_GET['page']) ? intval($_GET['page']) : 1);
  $start = ($pg -1)*$ppge;
  $nbpge = ceil($nbtitres/$ppge);
  //get last $nb_elts added not under moderation
  $sql = "SELECT * FROM musics WHERE MATCH (artiste, titre, album, genre, label) AGAINST (?) AND moderation=0 ".(isset($_GET['o']) ? "ORDER BY id DESC " : false)."LIMIT $start, $ppge";
  //echo $sql;
  $deb = microtime();
  $stm = $connect_bdd -> prepare($sql);
  $stm -> execute(array(het($_GET['q'])));
  $fin = microtime();
?>
<div class="center col s12" id="searchsingles">
  <div class="row s12">
  <h1 class="orange-text medium" style="font-size: 24pt;">
    Résultats de recherche: <strong><?=htmlspecialchars($_GET['q']);?> </strong>
  </h1>
  <p  class="flow-text">
     <?=$nbtitres;?> Morceau(x) :: <em style="text-transform: lowercase; font-size: small;">Recherche effectuée en <?=round($fin-$deb,7);?>s </em>
  </p>
<?php
if($nbtitres){
  //set in wordcloud
    $wc = $connect_bdd -> prepare("SELECT COUNT(*) AS itm FROM wordcloud WHERE mot=?");
    $wc -> execute(array(trim($_GET['q'])));
    list($wc_itm) = $wc -> fetch();
    $wc -> closeCursor();
    if($wc_itm){
      //count++
      $wc_pp = $connect_bdd -> prepare("UPDATE wordcloud SET vues=vues+1, trouve=1 WHERE mot=?");
      $wc_pp -> execute(array(trim($_GET['q'])));
      $wc_pp -> closeCursor();
    }else{
      $wc_ins = $connect_bdd -> prepare("INSERT INTO wordcloud(mot) VALUES(?)");
      $wc_ins -> execute(array(trim($_GET['q'])));
      $wc_ins -> closeCursor();
    }

  while ($res = $stm -> fetch()) {
    ?>
      <div class="col s6">
        <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
          <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="<?=$res['artiste'].' - '.$res['titre'];?>" class="responsive-img">
        </a>
        <br>
        <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>"><?=tronquer($res['artiste'].' - '.$res['titre'], 100);?></a>
        <br>
        <small><?=$res['hits'];?> hits</small>
      </div>
  <?php }
 }
else{
  //nothing found
    //set in wordcloud
    $wc = $connect_bdd -> prepare("SELECT COUNT(*) AS itm FROM wordcloud WHERE mot=?");
    $wc -> execute(array(trim($_GET['q'])));
    list($wc_itm) = $wc -> fetch();
    $wc -> closeCursor();
    if($wc_itm){
      //count++
      $wc_pp = $connect_bdd -> prepare("UPDATE wordcloud SET vues=vues+1, trouve=0 WHERE mot=?");
      $wc_pp -> execute(array(trim($_GET['q'])));
      $wc_pp -> closeCursor();
    }else{
      $wc_ins = $connect_bdd -> prepare("INSERT INTO wordcloud(mot,trouve) VALUES(?,0)");
      $wc_ins -> execute(array(trim($_GET['q'])));
      $wc_ins -> closeCursor();
    }
  echo '<center><em> Aucun résultat. Vous ne trouvez pas un morceau? Vous pouvez faire une demande <a href="'.MOBILE_BASE.'/club">au Club</a> </em></center>';
}
$stm -> closeCursor();
?>
    <div class='paginate'>
<?php
$previousy = ($pg == 1) ? '<span class="disabled">&lt;</span>' : '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.($pg-1).'">&lt;</a>';
echo $previousy;
if(($pg-2)>4){
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page=1">1</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page=2">2</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page=3">3</a>';
  echo '...';
}
for($i=$pg-2; $i<= $pg+2; $i++) {
  if($i==$pg)
    echo '<span class="current">'.$i.'</span>';
  elseif($i>0 && $i<=$nbpge)
    echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.$i.'">'.$i.'</a>';
}
if(($nbpge-3)>($pg+2)){
  echo '...';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.($nbpge-2).'">'.($nbpge-2).'</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.($nbpge-1).'">'.($nbpge-1).'</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.($nbpge).'">'.($nbpge).'</a>';
}
$nexty = ($pg >= $nbpge) ? '<span class="disabled">&gt;</span>' : '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page='.($pg+1).'">&gt;</a>';
echo $nexty;
?>
    </div>
  </div> <!-- end singles -->
</div>


  <center>
    <!-- pub -->
  </center>
<!-- albums -->

<div class="center col s12" id="searchalbums">
<?php
//if($nbtitres){
  $ppge = 25;
  $pg = (isset($_GET['page2']) ? intval($_GET['page2']) : 1);
  $start = ($pg -1)*$ppge;
  $nbpge = ceil($nbtitres2/$ppge);
  //get last $nb_elts added not under moderation
  $sql = "SELECT * FROM albums WHERE MATCH (artiste, nom, label, genre) AGAINST (?) AND moderation=0 ".(isset($_GET['o']) ? "ORDER BY id DESC " : false)."LIMIT $start, $ppge";
  //echo $sql;
  $deb = microtime();
  $stm = $connect_bdd -> prepare($sql);
  $stm -> execute(array(het($_GET['q'])));
  $fin = microtime();
?>
  <ul class="collection with-header">
  <li class="collection-header" ><h4 class="orange-text">Résultats de recherche: <?=htmlspecialchars($_GET['q']);?></h4>
  <small><?=$nbtitres2;?> Album(s) :: <em style="text-transform: lowercase;">Recherche effectuée en <?=round($fin-$deb,7);?>s </em></small></li>
<?php
  while ($res = $stm -> fetch()) {
    ?>
    <li class="collection-item row">
      <div class="col s5  left-align">
        <a href="<?=M_ABOUT_ALBUM.'/'.$res['code_name'];?>">
          <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="<?=$res['artiste'].' - '.$res['nom'];?>" class="responsive-img">
        </a>
      </div>
      <div class="col s7 left-align">
        <a href="<?=M_ABOUT_ALBUM.'/'.$res['code_name'];?>"><?=tronquer($res['artiste'].' - '.$res['nom'], 100);?></a> 
        <br><?=$res['annee'];?>
        <br>
        <?=count(explode(';',$res['id_titres']));?> morceaux - 
        vu <?=$res['hits'];?> fois
      </div>
    </li>
<?php }
$stm -> closeCursor();
if(!$nbtitres2){
  echo '<center><em> Aucun résultat. Vous ne trouvez pas un album? Vous pouvez faire une demande <a href="'.ROOT_SANS.'/club">au Club</a> </em></center>';
}
?>
</ul>
  <div class='paginate'>
<?php
$previousy = ($pg == 1) ? '<span class="disabled">&lt;</span>' : '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.($pg-1).'#searchalbums">&lt;</a>';
echo $previousy;
if(($pg-2)>4){
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2=1#searchalbums">1</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2=2#searchalbums">2</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2=3#searchalbums">3</a>';
  echo '...';
}
for($i=$pg-2; $i<= $pg+2; $i++) {
  if($i==$pg)
    echo '<span class="current">'.$i.'</span>';
  elseif($i>0 && $i<=$nbpge)
    echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.$i.'#searchalbums">'.$i.'</a>';
}
if(($nbpge-3)>($pg+2)){
  echo '...';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.($nbpge-2).'#searchalbums">'.($nbpge-2).'</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.($nbpge-1).'#searchalbums">'.($nbpge-1).'</a>';
  echo '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.($nbpge).'#searchalbums">'.($nbpge).'</a>';
}
$nexty = ($pg >= $nbpge) ? '<span class="disabled">&gt;</span>' : '<a href="'.M_SEARCH_BASE.'?q='.urlencode($_GET['q']).'&amp;content=search&amp;page2='.($pg+1).'#searchalbums">&gt;</a>';
echo $nexty;
?>        
  </div>
</div>