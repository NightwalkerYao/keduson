<br>
    <center class="s12 container"><img class="responsive-img" src="<?=ROOT_SANS;?>/logo.jpg" alt=""></center>
<div>
  <!-- publicites -->
</div>
<h1 style="font-size: 28pt;" class="orange-text center">Top Téléchargements KDS</h1>
<!-- <div class="divider grey"></div> -->
<ul class="collection with-header row s12">
  <li class="collection-header col s12">
    <ul class="tabs">
      <li class="tab col s6"><a href="#morceaux" class="active orange-text">MORCEAUX</a></li>
      <li class="tab col s6"><a href="#albums" class="orange-text">ALBUMS</a></li>
    </ul>
  </li>
  <div id="morceaux" class="col s12">
<?php
$a = 0;
$sql = "SELECT * FROM musics WHERE moderation=0 ORDER BY hits DESC LIMIT 100";
//echo $sql;
$stm = $connect_bdd -> prepare($sql);
$stm -> execute();
while ($res = $stm -> fetch()) {
  $a++;
  ?>
  <li class="collection-item row">
      <a class="col s4" href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
        <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '100X100', $res['pochette']);?>" alt="">
      </a>
      <div class="col s8 left-align">
        <span class="title">
          <?=$a;?>. <a class="orange-text" href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">
            <?=$res['artiste'].' - '.$res['titre'];?>
          </a>
          <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>" class="right"><i><img src="<?=MOBILE_BASE;?>/asset/png/32/star.png"></i></a>
        </span>
        <p> <?=$res['hits'];?> hits - <?=$res['duree'];?> - <?=round($res['taille']/pow(2, 20), 2);?>Mo <br>
           <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">Ecouter</a> | <a href="<?=M_ABOUT_SONG.'/'.$res['code_name'];?>">Télécharger</a> </p>
      </div>
  </li>
<?php }
$stm -> closeCursor();
?>
  </div>
  <div class="col s12" id="albums">
    <?php 
    $lalb = $connect_bdd -> prepare('SELECT * FROM albums WHERE moderation=0 ORDER BY hits DESC LIMIT 100');
    $lalb -> execute();
    while($res = $lalb->fetch()){ ?>
      <li class="collection-item row">
      <div class="col s5  left-align">
        <a href="<?=M_ABOUT_ALBUM.'/'.$res['code_name'];?>">
          <img src="<?=ROOT_SANS.'/covers/'.str_replace('500X500', '200X200', $res['pochette']);?>" alt="<?=$res['artiste'].' - '.$res['nom'];?>" class="responsive-img">
        </a>
      </div>
      <div class="col s7 left-align">
        <a href="<?=M_ABOUT_ALBUM.'/'.$res['code_name'];?>"><?=tronquer($res['artiste'].' - '.$res['nom'], 100);?></a> 
        <a href="<?=M_ABOUT_ALBUM.'/'.$res['code_name'];?>" class="right"><i><img src="<?=MOBILE_BASE;?>/asset/png/24/heart.png"></i></a>
        <br><span style="font-size: small; font-style: oblique;"><?=$res['annee'];?> | <?=$res['genre'];?>
        <br>
        <?=count(explode(';',$res['id_titres']));?> morceaux - 
        vu <?=$res['hits'];?> fois</span>
      </div>
    </li>
    <?php }
    $lalb -> closeCursor();
    ?>
  </div>
</ul>